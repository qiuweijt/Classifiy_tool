package classify_tool;
import jxl.*;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import java.io.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

public class Classify_tool extends JFrame{
	private static final long serialVersionUID = 1L;
	private JButton btnNext;	
	private JButton btnExit;
	private JLabel number;
	private JScrollPane JScrollPane1;
	private String number_mes1;
	private String number_mes2;
	private String number_mes3;
	private String number_mes4;
	private String number_mes5;
	private String number_mes6;
	private String number_mes7;
	private String number_mes8;
	private String number_mes9;
	private String oneMan;
	private String twoMan;
	private String threeMan;
	private String Row;
	private JTextField numberArea1;
	private JTextField numberArea2;
	private JTextArea cotArea;
	private JTextField numberArea4;
	private JTextField numberArea5;
	private JTextField numberArea6;
	private JTextField numberArea7;
	private JTextField numberArea8;
	private JTextField numberArea9;
	private JTextField numberArea10;
	private JLabel jLabel3;
	private String[] check = {"正确","错误"};
//	private String[] title = {"投诉编号", "原始分类", "机器自动分类一级", "机器自动分类二级", "机器自动分类三级", "人工分类一级", "人工分类二级", "人工分类三级","对或错","投诉内容"};
	private String[] title = {"投诉编号", "原始分类", "机器自动分类一级", "机器自动分类二级", "机器自动分类三级", "人工分类一级", "人工分类二级", "人工分类三级","对或错","投诉内容","截止该条准确率(%)"};
	@SuppressWarnings("rawtypes")
	private JComboBox setbox;
	private int n;
	private float T = 0;
	private float accuracy = 0;
	private JLabel jLabel4;
	File file = new File("text/社会诉求人工分类和自动分类对比.xls");
	private WritableWorkbook workbookA;
	private WritableSheet sheetA;
	
	//以文件路径读取文件，并获取改文件的指定行的内容
    public String readLineVarFile(String fileName, int lineNumber) throws IOException{ 
			@SuppressWarnings("resource")
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
            String line = reader.readLine();
            String mes = "";
            if (lineNumber <= 0 || lineNumber > getTotalLines(fileName))
			{ 
            	System.out.println("读出错误"); 
            } 
            int num = 1; 
            while (line != null){
            	if (lineNumber == num){ 
            		mes = line;
            		break;
                } 
                num++;
                line = reader.readLine();
            } 
			return mes; 
    } 
     
    //获取文件总行数
    public int getTotalLines(String fileName) throws IOException 
	{ 
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
            LineNumberReader reader = new LineNumberReader(br); 
            String s = reader.readLine();
            int lines = 0; 
            while (s != null)
			{ 
            	lines++; 
            	s = reader.readLine(); 
            } 
            reader.close(); 
            br.close(); 
            return lines;
    } 
	
	@SuppressWarnings({ "rawtypes", "unchecked"})
	public Classify_tool() throws IOException, RowsExceededException, WriteException, BiffException {
		
		if(file.exists()) {
   			Workbook workbookB = Workbook.getWorkbook(file);
   			workbookA = Workbook.createWorkbook(file,workbookB);
   			sheetA = workbookA.getSheet(0);
   			Sheet sheetB = workbookB.getSheet(0);
      		int row = sheetB.getRows();
      		n = row-1;
      		Row = String.valueOf(n);
      		String acy = sheetB.getCell(10, n-1).getContents();
      		T = Float.parseFloat(acy)*(n-1)/100;
      	}
      	else {
      		Row = "1";
      		n = 1;
      		file.createNewFile();
      		workbookA = Workbook.createWorkbook(file);
    		sheetA = workbookA.createSheet("工作表1", 0);
      		//设置列名
     		for(int i = 0;i < title.length;i++) {
      			sheetA.addCell(new Label(i,0,title[i]));
      		}
      	}
		number_mes1 = readLineVarFile("text/part6.txt",n);
		number_mes2 = readLineVarFile("text/part4.txt",n);
		number_mes3 = readLineVarFile("text/part2.txt",n);
		number_mes4 = readLineVarFile("text/one_classify.txt",n);
		number_mes6 = readLineVarFile("text/two_classify.txt",n);
		number_mes8 = readLineVarFile("text/three_classify.txt",n);
		
		//JFrame设计布局
		
		this.setTitle("语料标注工具");
		getContentPane().setLayout(null);
		
		//button下一条
		btnNext = new JButton();
		getContentPane().add(btnNext);
		btnNext.setText("下一条");
		btnNext.setBounds(340, 710, 120, 40);
		btnNext.setFont(new Font("正楷", Font.BOLD, 20));
		
		//button输出结果，打印标注内容至excel表格
		btnExit = new JButton();
		getContentPane().add(btnExit);
		btnExit.setText("输出结果");
		btnExit.setBounds(540, 710, 120, 40);
		btnExit.setFont(new Font("正楷", Font.BOLD, 19));

		number = new JLabel();
		getContentPane().add(number);
		number.setText("语料标注工具");
		number.setBounds(410, 20, 180, 25);
		number.setFont(new Font("正楷", Font.BOLD, 26));
		
		number = new JLabel();
		getContentPane().add(number);
		number.setText("投诉编号:");
		number.setBounds(40, 80, 160, 22);
		number.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea1 = new JTextField();
		getContentPane().add(numberArea1);
		numberArea1.setText(number_mes1);
		numberArea1.setBounds(145, 80, 320, 30);
		numberArea1.setFont(new Font("正楷", Font.BOLD ,18));
		
		number = new JLabel();
		getContentPane().add(number);
		number.setText("原始分类:");
		number.setBounds(510, 80, 160, 25);
		number.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea2 = new JTextField();
		getContentPane().add(numberArea2);
		numberArea2.setText(number_mes2);
		numberArea2.setBounds(620, 80, 320, 30);
		numberArea2.setFont(new Font("正楷", Font.BOLD ,18));

		jLabel3 = new JLabel();
		getContentPane().add(jLabel3);
		jLabel3.setText("投诉内容:");
		jLabel3.setBounds(40, 140, 100, 30);
		jLabel3.setFont(new Font("正楷", Font.BOLD, 22));
		
		JScrollPane1 = new JScrollPane();
		getContentPane().add(JScrollPane1);
		JScrollPane1.setBounds(145, 140, 795, 100);
		
		cotArea = new JTextArea();
		cotArea.setBounds(145, 140, 795, 100);
		cotArea.setText(number_mes3);
		cotArea.setLineWrap(true);
		cotArea.setCaretPosition(0);
		cotArea.setFont(new Font("正楷", Font.BOLD, 18));
		JScrollPane1.setViewportView(cotArea);
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器一级:");
		jLabel4.setBounds(40, 270, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea4 = new JTextField();
		getContentPane().add(numberArea4);
		numberArea4.setText(number_mes4);
		numberArea4.setBounds(145, 270, 320, 30);
		numberArea4.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器二级:");
		jLabel4.setBounds(40, 330, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea6 = new JTextField();
		getContentPane().add(numberArea6);
		numberArea6.setText(number_mes6);
		numberArea6.setBounds(145, 330, 320, 30);
		numberArea6.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器三级:");
		jLabel4.setBounds(40, 390, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea8 = new JTextField();
		getContentPane().add(numberArea8);
		numberArea8.setText(number_mes8);
		numberArea8.setBounds(145, 390, 320, 30);
		numberArea8.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("人工一级:");
		jLabel4.setBounds(40, 450, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea5 = new JTextField();
		getContentPane().add(numberArea5);
		numberArea5.setText(oneMan);
		numberArea5.setBounds(145, 450, 320, 30);
		numberArea5.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("人工二级:");
		jLabel4.setBounds(40, 510, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea7 = new JTextField();
		getContentPane().add(numberArea7);
		numberArea7.setText(twoMan);
		numberArea7.setBounds(145, 510, 320, 30);
		numberArea7.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("人工三级:");
		jLabel4.setBounds(40, 570, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea9 = new JTextField();
		getContentPane().add(numberArea9);
		numberArea9.setText(threeMan);
		numberArea9.setBounds(145, 570, 320, 30);
		numberArea9.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器判断情况:");
		jLabel4.setBounds(40, 630, 160, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("第");
		jLabel4.setBounds(40, 690, 25, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 20));
		
		numberArea10 = new JTextField();
		getContentPane().add(numberArea10);
		numberArea10.setText(Row);
		numberArea10.setBounds(65, 693, 50, 27);
		numberArea10.setFont(new Font("正楷", Font.BOLD ,18));
		numberArea10.setBorder(null);
		numberArea10.setSelectionColor(getBackground());;
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("条");
		jLabel4.setBounds(120, 690, 30, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 20));
		
		//机器判断情况的下拉菜单
//		@SuppressWarnings({ })
		ComboBoxModel setboxModel = new DefaultComboBoxModel(check);
		setbox = new JComboBox();
		getContentPane().add(setbox);
		setbox.setModel(setboxModel);
		setbox.setBounds(210, 630, 90, 33);
		setbox.setFont(new Font("正楷", Font.BOLD, 20));
		
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBounds(540, 260, 400, 410);
        
        //根节点
        DefaultMutableTreeNode Node = new DefaultMutableTreeNode("人工分类");
        
        // 创建一级节点
        DefaultMutableTreeNode Node1_1 = new DefaultMutableTreeNode("农村农业");
        DefaultMutableTreeNode Node1_2 = new DefaultMutableTreeNode("国土资源管理");
        DefaultMutableTreeNode Node1_3 = new DefaultMutableTreeNode("城乡建设");
        DefaultMutableTreeNode Node1_4 = new DefaultMutableTreeNode("劳动和社会保障");
        DefaultMutableTreeNode Node1_5 = new DefaultMutableTreeNode("卫生生计");
        DefaultMutableTreeNode Node1_6 = new DefaultMutableTreeNode("教育文体");
        DefaultMutableTreeNode Node1_7 = new DefaultMutableTreeNode("民政");
        DefaultMutableTreeNode Node1_8 = new DefaultMutableTreeNode("政法");
        DefaultMutableTreeNode Node1_9 = new DefaultMutableTreeNode("经济管理");
        DefaultMutableTreeNode Node1_10 = new DefaultMutableTreeNode("交通运输");
        DefaultMutableTreeNode Node1_11 = new DefaultMutableTreeNode("商贸旅游");
        DefaultMutableTreeNode Node1_12 = new DefaultMutableTreeNode("科技与信息产业");
        DefaultMutableTreeNode Node1_13 = new DefaultMutableTreeNode("环境保护");
        DefaultMutableTreeNode Node1_14 = new DefaultMutableTreeNode("党务政务");
        DefaultMutableTreeNode Node1_15 = new DefaultMutableTreeNode("组织人事");
        DefaultMutableTreeNode Node1_16 = new DefaultMutableTreeNode("纪检监察");
        DefaultMutableTreeNode Node1_17 = new DefaultMutableTreeNode("其他");
        
        //设置根节点下方一级节点
        Node.add(Node1_1);
        Node.add(Node1_2);
        Node.add(Node1_3);
        Node.add(Node1_4);
        Node.add(Node1_5);
        Node.add(Node1_6);
        Node.add(Node1_7);
        Node.add(Node1_8);
        Node.add(Node1_9);
        Node.add(Node1_10);
        Node.add(Node1_11);
        Node.add(Node1_12);
        Node.add(Node1_13);
        Node.add(Node1_14);
        Node.add(Node1_15);
        Node.add(Node1_16);
        Node.add(Node1_17);

        // 创建二级节点
        DefaultMutableTreeNode Node2_1 = new DefaultMutableTreeNode("村务管理");
        DefaultMutableTreeNode Node2_2 = new DefaultMutableTreeNode("土地承包经营");
        DefaultMutableTreeNode Node2_3 = new DefaultMutableTreeNode("扶贫开发");
        DefaultMutableTreeNode Node2_4 = new DefaultMutableTreeNode("农副产品流通");
        DefaultMutableTreeNode Node2_5 = new DefaultMutableTreeNode("农资农技");
        DefaultMutableTreeNode Node2_6 = new DefaultMutableTreeNode("农垦农场");
        DefaultMutableTreeNode Node2_7 = new DefaultMutableTreeNode("动物预防");
        DefaultMutableTreeNode Node2_8 = new DefaultMutableTreeNode("林业管理");
        DefaultMutableTreeNode Node2_9 = new DefaultMutableTreeNode("野生资源管理");
        DefaultMutableTreeNode Node2_10 = new DefaultMutableTreeNode("水利水电");
        DefaultMutableTreeNode Node2_11 = new DefaultMutableTreeNode("水库移民");
        DefaultMutableTreeNode Node2_12 = new DefaultMutableTreeNode("惠农补贴");
        DefaultMutableTreeNode Node2_13 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_14 = new DefaultMutableTreeNode("土地资源管理");
        DefaultMutableTreeNode Node2_15 = new DefaultMutableTreeNode("土地征收");
        DefaultMutableTreeNode Node2_16 = new DefaultMutableTreeNode("破产资源管理");
        DefaultMutableTreeNode Node2_17 = new DefaultMutableTreeNode("气象地震"); 
        DefaultMutableTreeNode Node2_18 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_19 = new DefaultMutableTreeNode("国有土地上房屋征收与补偿");
        DefaultMutableTreeNode Node2_20 = new DefaultMutableTreeNode("城市建设和市政管理");
        DefaultMutableTreeNode Node2_21 = new DefaultMutableTreeNode("城乡规划");
        DefaultMutableTreeNode Node2_22 = new DefaultMutableTreeNode("住房保障与房地产");
        DefaultMutableTreeNode Node2_23 = new DefaultMutableTreeNode("建筑市场");
        DefaultMutableTreeNode Node2_24 = new DefaultMutableTreeNode("工程质量");
        DefaultMutableTreeNode Node2_25 = new DefaultMutableTreeNode("村镇建设");
        DefaultMutableTreeNode Node2_26 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_27 = new DefaultMutableTreeNode("城镇职工社会保险");
        DefaultMutableTreeNode Node2_28 = new DefaultMutableTreeNode("城镇居民社会保险");
        DefaultMutableTreeNode Node2_29 = new DefaultMutableTreeNode("社保基金管理");
        DefaultMutableTreeNode Node2_30 = new DefaultMutableTreeNode("工资福利");
        DefaultMutableTreeNode Node2_31 = new DefaultMutableTreeNode("就业培训");
        DefaultMutableTreeNode Node2_32 = new DefaultMutableTreeNode("劳动保护");
        DefaultMutableTreeNode Node2_33 = new DefaultMutableTreeNode("劳动关系");
        DefaultMutableTreeNode Node2_34 = new DefaultMutableTreeNode("退休政策及待遇");
        DefaultMutableTreeNode Node2_35 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_36 = new DefaultMutableTreeNode("公共卫生");
        DefaultMutableTreeNode Node2_37 = new DefaultMutableTreeNode("食品药品监督");
        DefaultMutableTreeNode Node2_38 = new DefaultMutableTreeNode("医政管理");
        DefaultMutableTreeNode Node2_39 = new DefaultMutableTreeNode("医患纠纷");
        DefaultMutableTreeNode Node2_40 = new DefaultMutableTreeNode("人口生计"); 
        DefaultMutableTreeNode Node2_41 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_42 = new DefaultMutableTreeNode("教育体制");
        DefaultMutableTreeNode Node2_43 = new DefaultMutableTreeNode("考试招生");
        DefaultMutableTreeNode Node2_44 = new DefaultMutableTreeNode("教育行政管理");
        DefaultMutableTreeNode Node2_45 = new DefaultMutableTreeNode("教师队伍待遇");
        DefaultMutableTreeNode Node2_46 = new DefaultMutableTreeNode("失学辍学");
        DefaultMutableTreeNode Node2_47 = new DefaultMutableTreeNode("文化");
        DefaultMutableTreeNode Node2_48 = new DefaultMutableTreeNode("文物管理");
        DefaultMutableTreeNode Node2_49 = new DefaultMutableTreeNode("体育");
        DefaultMutableTreeNode Node2_50 = new DefaultMutableTreeNode("入学");
        DefaultMutableTreeNode Node2_51 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_52 = new DefaultMutableTreeNode("基层选举和社区建设");
        DefaultMutableTreeNode Node2_53 = new DefaultMutableTreeNode("优抚");
        DefaultMutableTreeNode Node2_54 = new DefaultMutableTreeNode("复退安置");
        DefaultMutableTreeNode Node2_55 = new DefaultMutableTreeNode("社会救助");
        DefaultMutableTreeNode Node2_56 = new DefaultMutableTreeNode("区划地名");
        DefaultMutableTreeNode Node2_57 = new DefaultMutableTreeNode("民间组织");
        DefaultMutableTreeNode Node2_58 = new DefaultMutableTreeNode("救助募捐");
        DefaultMutableTreeNode Node2_59 = new DefaultMutableTreeNode("福利慈善");
        DefaultMutableTreeNode Node2_60 = new DefaultMutableTreeNode("社会服务");
        DefaultMutableTreeNode Node2_61 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_62 = new DefaultMutableTreeNode("法制建设");
        DefaultMutableTreeNode Node2_63 = new DefaultMutableTreeNode("诉讼");
        DefaultMutableTreeNode Node2_64 = new DefaultMutableTreeNode("仲裁与调节");
        DefaultMutableTreeNode Node2_65 = new DefaultMutableTreeNode("行政复议");
        DefaultMutableTreeNode Node2_66 = new DefaultMutableTreeNode("法律服务");
        DefaultMutableTreeNode Node2_67 = new DefaultMutableTreeNode("刑罚执行");
        DefaultMutableTreeNode Node2_68 = new DefaultMutableTreeNode("警务监督");
        DefaultMutableTreeNode Node2_69 = new DefaultMutableTreeNode("社会治安");
        DefaultMutableTreeNode Node2_70 = new DefaultMutableTreeNode("交通管理");
        DefaultMutableTreeNode Node2_71 = new DefaultMutableTreeNode("刑案侦破");
        DefaultMutableTreeNode Node2_72 = new DefaultMutableTreeNode("户籍证件");
        DefaultMutableTreeNode Node2_73 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_74 = new DefaultMutableTreeNode("宏观调控");
        DefaultMutableTreeNode Node2_75 = new DefaultMutableTreeNode("金融财税");
        DefaultMutableTreeNode Node2_76 = new DefaultMutableTreeNode("保险证券期货");
        DefaultMutableTreeNode Node2_77 = new DefaultMutableTreeNode("国资监管");
        DefaultMutableTreeNode Node2_78 = new DefaultMutableTreeNode("能源管理");
        DefaultMutableTreeNode Node2_79 = new DefaultMutableTreeNode("企业破产");
        DefaultMutableTreeNode Node2_80 = new DefaultMutableTreeNode("安全生产");
        DefaultMutableTreeNode Node2_81 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_82 = new DefaultMutableTreeNode("建设管理");
        DefaultMutableTreeNode Node2_83 = new DefaultMutableTreeNode("客货运输");
        DefaultMutableTreeNode Node2_84 = new DefaultMutableTreeNode("邮政管理");
        DefaultMutableTreeNode Node2_85 = new DefaultMutableTreeNode("出租车管理");
        DefaultMutableTreeNode Node2_86 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_87 = new DefaultMutableTreeNode("商业贸易");
        DefaultMutableTreeNode Node2_88 = new DefaultMutableTreeNode("市场监管");
        DefaultMutableTreeNode Node2_89 = new DefaultMutableTreeNode("质检检验检疫");
        DefaultMutableTreeNode Node2_90 = new DefaultMutableTreeNode("旅游管理");
        DefaultMutableTreeNode Node2_91 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_92 = new DefaultMutableTreeNode("科学技术");
        DefaultMutableTreeNode Node2_93 = new DefaultMutableTreeNode("知识产权");
        DefaultMutableTreeNode Node2_94 = new DefaultMutableTreeNode("信息化建设");
        DefaultMutableTreeNode Node2_95 = new DefaultMutableTreeNode("电信");
        DefaultMutableTreeNode Node2_96 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_97 = new DefaultMutableTreeNode("环境污染");
        DefaultMutableTreeNode Node2_98 = new DefaultMutableTreeNode("建设项目审批");
        DefaultMutableTreeNode Node2_99 = new DefaultMutableTreeNode("环保管理");
        DefaultMutableTreeNode Node2_100 = new DefaultMutableTreeNode("党的建设");
        DefaultMutableTreeNode Node2_101 = new DefaultMutableTreeNode("政治体制");
        DefaultMutableTreeNode Node2_102 = new DefaultMutableTreeNode("民族宗教");
        DefaultMutableTreeNode Node2_103 = new DefaultMutableTreeNode("港澳台侨");
        DefaultMutableTreeNode Node2_104 = new DefaultMutableTreeNode("国防外交");
        DefaultMutableTreeNode Node2_105 = new DefaultMutableTreeNode("群众团体");
        DefaultMutableTreeNode Node2_106 = new DefaultMutableTreeNode("宣传舆论");
        DefaultMutableTreeNode Node2_107 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_108 = new DefaultMutableTreeNode("选拔任用");
        DefaultMutableTreeNode Node2_109 = new DefaultMutableTreeNode("招录辞退");
        DefaultMutableTreeNode Node2_110 = new DefaultMutableTreeNode("编制职位");
        DefaultMutableTreeNode Node2_111 = new DefaultMutableTreeNode("人力资源");
        DefaultMutableTreeNode Node2_112 = new DefaultMutableTreeNode("军转安置");
        DefaultMutableTreeNode Node2_113 = new DefaultMutableTreeNode("贪污贿赂");
        DefaultMutableTreeNode Node2_114 = new DefaultMutableTreeNode("滥用职权");
        DefaultMutableTreeNode Node2_115 = new DefaultMutableTreeNode("失职渎职");
        DefaultMutableTreeNode Node2_116 = new DefaultMutableTreeNode("干部作风");
        DefaultMutableTreeNode Node2_117 = new DefaultMutableTreeNode("党政处分");
        DefaultMutableTreeNode Node2_118 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node2_119 = new DefaultMutableTreeNode("历史遗留问题");
        DefaultMutableTreeNode Node2_120 = new DefaultMutableTreeNode("其他");

        // 把二级节点作为子节点添加到根节点
        Node1_1.add(Node2_1);
        Node1_1.add(Node2_2);
        Node1_1.add(Node2_3);
        Node1_1.add(Node2_4);
        Node1_1.add(Node2_5);
        Node1_1.add(Node2_6);
        Node1_1.add(Node2_7);
        Node1_1.add(Node2_8);
        Node1_1.add(Node2_9);
        Node1_1.add(Node2_10);
        Node1_1.add(Node2_11);
        Node1_1.add(Node2_12);
        Node1_1.add(Node2_13);
        Node1_2.add(Node2_14);
        Node1_2.add(Node2_15);
        Node1_2.add(Node2_16);
        Node1_2.add(Node2_17);
        Node1_2.add(Node2_18);
        Node1_3.add(Node2_19);
        Node1_3.add(Node2_20);
        Node1_3.add(Node2_21);
        Node1_3.add(Node2_22);
        Node1_3.add(Node2_23);
        Node1_3.add(Node2_24);
        Node1_3.add(Node2_25);
        Node1_3.add(Node2_26);
        Node1_4.add(Node2_27);
        Node1_4.add(Node2_28);
        Node1_4.add(Node2_29);
        Node1_4.add(Node2_30);
        Node1_4.add(Node2_31);
        Node1_4.add(Node2_32);
        Node1_4.add(Node2_33);
        Node1_4.add(Node2_34);
        Node1_4.add(Node2_35);
        Node1_5.add(Node2_36);
        Node1_5.add(Node2_37);
        Node1_5.add(Node2_38);
        Node1_5.add(Node2_39);
        Node1_5.add(Node2_40);
        Node1_5.add(Node2_41);
        Node1_6.add(Node2_42);
        Node1_6.add(Node2_43);
        Node1_6.add(Node2_44);
        Node1_6.add(Node2_45);
        Node1_6.add(Node2_46);
        Node1_6.add(Node2_47);
        Node1_6.add(Node2_48);
        Node1_6.add(Node2_49);
        Node1_6.add(Node2_50);
        Node1_6.add(Node2_51);
        Node1_7.add(Node2_52);
        Node1_7.add(Node2_53);
        Node1_7.add(Node2_54);
        Node1_7.add(Node2_55);
        Node1_7.add(Node2_56);
        Node1_7.add(Node2_57);
        Node1_7.add(Node2_58);
        Node1_7.add(Node2_59);
        Node1_7.add(Node2_60);
        Node1_7.add(Node2_61);
        Node1_8.add(Node2_62);
        Node1_8.add(Node2_63);
        Node1_8.add(Node2_64);
        Node1_8.add(Node2_65);
        Node1_8.add(Node2_66);
        Node1_8.add(Node2_67);
        Node1_8.add(Node2_68);
        Node1_8.add(Node2_69);
        Node1_8.add(Node2_70);
        Node1_8.add(Node2_71);
        Node1_8.add(Node2_72);
        Node1_8.add(Node2_73);
        Node1_9.add(Node2_74);
        Node1_9.add(Node2_75);
        Node1_9.add(Node2_76);
        Node1_9.add(Node2_77);
        Node1_9.add(Node2_78);
        Node1_9.add(Node2_79);
        Node1_9.add(Node2_80);
        Node1_9.add(Node2_81);
        Node1_10.add(Node2_82);
        Node1_10.add(Node2_83);
        Node1_10.add(Node2_84);
        Node1_10.add(Node2_85);
        Node1_10.add(Node2_86);
        Node1_11.add(Node2_87);
        Node1_11.add(Node2_88);
        Node1_11.add(Node2_89);
        Node1_11.add(Node2_90);
        Node1_11.add(Node2_91);
        Node1_12.add(Node2_92);
        Node1_12.add(Node2_93);
        Node1_12.add(Node2_94);
        Node1_12.add(Node2_95);
        Node1_12.add(Node2_96);
        Node1_13.add(Node2_97);
        Node1_13.add(Node2_98);
        Node1_13.add(Node2_99);
        Node1_14.add(Node2_100);
        Node1_14.add(Node2_101);
        Node1_14.add(Node2_102);
        Node1_14.add(Node2_103);
        Node1_14.add(Node2_104);
        Node1_14.add(Node2_105);
        Node1_14.add(Node2_106);
        Node1_14.add(Node2_107);
        Node1_15.add(Node2_108);
        Node1_15.add(Node2_109);
        Node1_15.add(Node2_110);
        Node1_15.add(Node2_111);
        Node1_15.add(Node2_112);
        Node1_16.add(Node2_113);
        Node1_16.add(Node2_114);
        Node1_16.add(Node2_115);
        Node1_16.add(Node2_116);
        Node1_16.add(Node2_117);
        Node1_16.add(Node2_118);
        Node1_17.add(Node2_119);
        Node1_17.add(Node2_120);

        // 创建三级节点
        DefaultMutableTreeNode Node3_1 = new DefaultMutableTreeNode("集体资产管理");
        DefaultMutableTreeNode Node3_2 = new DefaultMutableTreeNode("集体财务管理");
        DefaultMutableTreeNode Node3_3 = new DefaultMutableTreeNode("村务公开");
        DefaultMutableTreeNode Node3_4 = new DefaultMutableTreeNode("村级债务");
        DefaultMutableTreeNode Node3_5 = new DefaultMutableTreeNode("土地承包");
        DefaultMutableTreeNode Node3_6 = new DefaultMutableTreeNode("土地流转");
        DefaultMutableTreeNode Node3_7 = new DefaultMutableTreeNode("宅基地纠纷");
        DefaultMutableTreeNode Node3_8 = new DefaultMutableTreeNode("扶贫开发政策");
        DefaultMutableTreeNode Node3_9 = new DefaultMutableTreeNode("扶贫开发资金使用管理");
        DefaultMutableTreeNode Node3_10 = new DefaultMutableTreeNode("农药、种子");
        DefaultMutableTreeNode Node3_11 = new DefaultMutableTreeNode("农业生产保险");
        DefaultMutableTreeNode Node3_12 = new DefaultMutableTreeNode("生猪溯源");
        DefaultMutableTreeNode Node3_13 = new DefaultMutableTreeNode("价格质量");
        DefaultMutableTreeNode Node3_14 = new DefaultMutableTreeNode("运输购销");
        DefaultMutableTreeNode Node3_15 = new DefaultMutableTreeNode("粮食储备");
        DefaultMutableTreeNode Node3_16 = new DefaultMutableTreeNode("农资价格质量");
        DefaultMutableTreeNode Node3_17 = new DefaultMutableTreeNode("农技推广应用"); 
        DefaultMutableTreeNode Node3_18 = new DefaultMutableTreeNode("经营管理");
        DefaultMutableTreeNode Node3_19 = new DefaultMutableTreeNode("职工待遇");
        DefaultMutableTreeNode Node3_20 = new DefaultMutableTreeNode("疫情防控");
        DefaultMutableTreeNode Node3_21 = new DefaultMutableTreeNode("扑杀补偿");
        DefaultMutableTreeNode Node3_22 = new DefaultMutableTreeNode("国有林业资产管理");
        DefaultMutableTreeNode Node3_23 = new DefaultMutableTreeNode("水土流失");
        DefaultMutableTreeNode Node3_24 = new DefaultMutableTreeNode("退耕还林");
        DefaultMutableTreeNode Node3_25 = new DefaultMutableTreeNode("采伐运输");
        DefaultMutableTreeNode Node3_26 = new DefaultMutableTreeNode("森林防火");
        DefaultMutableTreeNode Node3_27 = new DefaultMutableTreeNode("林权改革及权属纠纷");
        DefaultMutableTreeNode Node3_28 = new DefaultMutableTreeNode("野生动植物保护");
        DefaultMutableTreeNode Node3_29 = new DefaultMutableTreeNode("其他野生资源管理");
        DefaultMutableTreeNode Node3_30 = new DefaultMutableTreeNode("禁渔期间非法捕鱼");
        DefaultMutableTreeNode Node3_31 = new DefaultMutableTreeNode("农业灌溉");
        DefaultMutableTreeNode Node3_32 = new DefaultMutableTreeNode("雨污处理");
        DefaultMutableTreeNode Node3_33 = new DefaultMutableTreeNode("规划设计");
        DefaultMutableTreeNode Node3_34 = new DefaultMutableTreeNode("工程建设管理");
        DefaultMutableTreeNode Node3_35 = new DefaultMutableTreeNode("防汛抗旱");
        DefaultMutableTreeNode Node3_36 = new DefaultMutableTreeNode("江河湖治理");
        DefaultMutableTreeNode Node3_37 = new DefaultMutableTreeNode("引水调水");
        DefaultMutableTreeNode Node3_38 = new DefaultMutableTreeNode("水事纠纷");
        DefaultMutableTreeNode Node3_39 = new DefaultMutableTreeNode("移民补偿安置");
        DefaultMutableTreeNode Node3_40 = new DefaultMutableTreeNode("后期扶持");
        DefaultMutableTreeNode Node3_41 = new DefaultMutableTreeNode("粮食直补");
        DefaultMutableTreeNode Node3_42 = new DefaultMutableTreeNode("农机农资补贴");
        DefaultMutableTreeNode Node3_43 = new DefaultMutableTreeNode("良种补贴");
        DefaultMutableTreeNode Node3_44 = new DefaultMutableTreeNode("其他补贴");
        DefaultMutableTreeNode Node3_45 = new DefaultMutableTreeNode("农村“八大责”问题");
        DefaultMutableTreeNode Node3_46 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_47 = new DefaultMutableTreeNode("土地规划");
        DefaultMutableTreeNode Node3_48 = new DefaultMutableTreeNode("耕地保护");
        DefaultMutableTreeNode Node3_49 = new DefaultMutableTreeNode("土地权属纠纷");
        DefaultMutableTreeNode Node3_50 = new DefaultMutableTreeNode("土地转让");
        DefaultMutableTreeNode Node3_51 = new DefaultMutableTreeNode("盗挖砂石");
        DefaultMutableTreeNode Node3_52 = new DefaultMutableTreeNode("土地占地");
        DefaultMutableTreeNode Node3_53 = new DefaultMutableTreeNode("失地农民保障");
        DefaultMutableTreeNode Node3_54 = new DefaultMutableTreeNode("地质勘查");
        DefaultMutableTreeNode Node3_55 = new DefaultMutableTreeNode("矿产开采");
        DefaultMutableTreeNode Node3_56 = new DefaultMutableTreeNode("矿山资质环境");
        DefaultMutableTreeNode Node3_57 = new DefaultMutableTreeNode("气象"); 
        DefaultMutableTreeNode Node3_58 = new DefaultMutableTreeNode("地震");
        DefaultMutableTreeNode Node3_59 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_60 = new DefaultMutableTreeNode("城市房屋拆迁");
        DefaultMutableTreeNode Node3_61 = new DefaultMutableTreeNode("回迁房");
        DefaultMutableTreeNode Node3_62 = new DefaultMutableTreeNode("棚户区和城中村改造");
        DefaultMutableTreeNode Node3_63 = new DefaultMutableTreeNode("城镇危房改造");
        DefaultMutableTreeNode Node3_64 = new DefaultMutableTreeNode("城市公共设施");
        DefaultMutableTreeNode Node3_65 = new DefaultMutableTreeNode("园林绿化环卫");
        DefaultMutableTreeNode Node3_66 = new DefaultMutableTreeNode("居民服务设施");
        DefaultMutableTreeNode Node3_67 = new DefaultMutableTreeNode("城市执法");
        DefaultMutableTreeNode Node3_68 = new DefaultMutableTreeNode("占道经营");
        DefaultMutableTreeNode Node3_69 = new DefaultMutableTreeNode("油烟扰民");
        DefaultMutableTreeNode Node3_70 = new DefaultMutableTreeNode("垃圾收运、垃圾站的设置及管理");
        DefaultMutableTreeNode Node3_71 = new DefaultMutableTreeNode("道路、桥梁、隔离栏的维护");
        DefaultMutableTreeNode Node3_72 = new DefaultMutableTreeNode("城市照明设施");
        DefaultMutableTreeNode Node3_73 = new DefaultMutableTreeNode("户外广告的设置及维护");
        DefaultMutableTreeNode Node3_74 = new DefaultMutableTreeNode("新增道路桥梁");
        DefaultMutableTreeNode Node3_75 = new DefaultMutableTreeNode("规划方案");
        DefaultMutableTreeNode Node3_76 = new DefaultMutableTreeNode("历史名城保护");
        DefaultMutableTreeNode Node3_77 = new DefaultMutableTreeNode("违章建筑");
        DefaultMutableTreeNode Node3_78 = new DefaultMutableTreeNode("容积挡光");
        DefaultMutableTreeNode Node3_79 = new DefaultMutableTreeNode("保障性住房");
        DefaultMutableTreeNode Node3_80 = new DefaultMutableTreeNode("商品房、二手房");
        DefaultMutableTreeNode Node3_81 = new DefaultMutableTreeNode("房屋中介管理");
        DefaultMutableTreeNode Node3_82 = new DefaultMutableTreeNode("住改商");
        DefaultMutableTreeNode Node3_83 = new DefaultMutableTreeNode("房地产开发管理");
        DefaultMutableTreeNode Node3_84 = new DefaultMutableTreeNode("产权交易");
        DefaultMutableTreeNode Node3_85 = new DefaultMutableTreeNode("物业服务");
        DefaultMutableTreeNode Node3_86 = new DefaultMutableTreeNode("水电气");
        DefaultMutableTreeNode Node3_87 = new DefaultMutableTreeNode("住房公积金");
        DefaultMutableTreeNode Node3_88 = new DefaultMutableTreeNode("工程招投标");
        DefaultMutableTreeNode Node3_89 = new DefaultMutableTreeNode("勘察涉及和施工监管");
        DefaultMutableTreeNode Node3_90 = new DefaultMutableTreeNode("企业资质和执业资格");
        DefaultMutableTreeNode Node3_91 = new DefaultMutableTreeNode("拖欠工程款");
        DefaultMutableTreeNode Node3_92 = new DefaultMutableTreeNode("工程质量");
        DefaultMutableTreeNode Node3_93 = new DefaultMutableTreeNode("施工安全");
        DefaultMutableTreeNode Node3_94 = new DefaultMutableTreeNode("抗震救灾");
        DefaultMutableTreeNode Node3_95 = new DefaultMutableTreeNode("小城镇建设");
        DefaultMutableTreeNode Node3_96 = new DefaultMutableTreeNode("新农村建设");
        DefaultMutableTreeNode Node3_97 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_98 = new DefaultMutableTreeNode("职工养老保险");
        DefaultMutableTreeNode Node3_99 = new DefaultMutableTreeNode("职工医疗保险");
        DefaultMutableTreeNode Node3_100 = new DefaultMutableTreeNode("职工失业保险");
        DefaultMutableTreeNode Node3_101 = new DefaultMutableTreeNode("职工工商保险");
        DefaultMutableTreeNode Node3_102 = new DefaultMutableTreeNode("职工生育保险");
        DefaultMutableTreeNode Node3_103 = new DefaultMutableTreeNode("城乡居民养老保险");
        DefaultMutableTreeNode Node3_104 = new DefaultMutableTreeNode("城乡居民医疗保险");
        DefaultMutableTreeNode Node3_105 = new DefaultMutableTreeNode("新农村合作医疗");
        DefaultMutableTreeNode Node3_106 = new DefaultMutableTreeNode("少儿互助金");
        DefaultMutableTreeNode Node3_107 = new DefaultMutableTreeNode("社保基金管理");
        DefaultMutableTreeNode Node3_108 = new DefaultMutableTreeNode("工资调整");
        DefaultMutableTreeNode Node3_109 = new DefaultMutableTreeNode("工资发放");
        DefaultMutableTreeNode Node3_110 = new DefaultMutableTreeNode("福利待遇");
        DefaultMutableTreeNode Node3_111 = new DefaultMutableTreeNode("最低工资标准");
        DefaultMutableTreeNode Node3_112 = new DefaultMutableTreeNode("婚假、产假、法定假");
        DefaultMutableTreeNode Node3_113 = new DefaultMutableTreeNode("就业和再就业");
        DefaultMutableTreeNode Node3_114 = new DefaultMutableTreeNode("职工培训");
        DefaultMutableTreeNode Node3_115 = new DefaultMutableTreeNode("职业技能鉴定");
        DefaultMutableTreeNode Node3_116 = new DefaultMutableTreeNode("劳动环境");
        DefaultMutableTreeNode Node3_117 = new DefaultMutableTreeNode("劳动安全");
        DefaultMutableTreeNode Node3_118 = new DefaultMutableTreeNode("女工保护");
        DefaultMutableTreeNode Node3_119 = new DefaultMutableTreeNode("工作时间和休息假期");
        DefaultMutableTreeNode Node3_120 = new DefaultMutableTreeNode("劳动合同纠纷");
        DefaultMutableTreeNode Node3_121 = new DefaultMutableTreeNode("协议解除劳动关系");
        DefaultMutableTreeNode Node3_122 = new DefaultMutableTreeNode("劳动派遣纠纷");
        DefaultMutableTreeNode Node3_123 = new DefaultMutableTreeNode("非法用工");
        DefaultMutableTreeNode Node3_124 = new DefaultMutableTreeNode("农民工权益");
        DefaultMutableTreeNode Node3_125 = new DefaultMutableTreeNode("退休政策");
        DefaultMutableTreeNode Node3_126 = new DefaultMutableTreeNode("退休人员待遇");
        DefaultMutableTreeNode Node3_127 = new DefaultMutableTreeNode("内部退休人员待遇");
        DefaultMutableTreeNode Node3_128 = new DefaultMutableTreeNode("病退及提前退休人员待遇");
        DefaultMutableTreeNode Node3_129 = new DefaultMutableTreeNode("退休金发放");
        DefaultMutableTreeNode Node3_130 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_131 = new DefaultMutableTreeNode("公共卫生");
        DefaultMutableTreeNode Node3_132 = new DefaultMutableTreeNode("疾病预防控制");
        DefaultMutableTreeNode Node3_133 = new DefaultMutableTreeNode("突发公共卫生事件处理");
        DefaultMutableTreeNode Node3_134 = new DefaultMutableTreeNode("食品安全");
        DefaultMutableTreeNode Node3_135 = new DefaultMutableTreeNode("药品和医疗器械管理");
        DefaultMutableTreeNode Node3_136 = new DefaultMutableTreeNode("保健品化妆品管理");
        DefaultMutableTreeNode Node3_137 = new DefaultMutableTreeNode("医疗机构管理");
        DefaultMutableTreeNode Node3_138 = new DefaultMutableTreeNode("医务人员管理");
        DefaultMutableTreeNode Node3_139 = new DefaultMutableTreeNode("医疗技术和服务");
        DefaultMutableTreeNode Node3_140 = new DefaultMutableTreeNode("血液管理");
        DefaultMutableTreeNode Node3_141 = new DefaultMutableTreeNode("医疗收费");
        DefaultMutableTreeNode Node3_142 = new DefaultMutableTreeNode("非法行医");
        DefaultMutableTreeNode Node3_143 = new DefaultMutableTreeNode("卫生执法");
        DefaultMutableTreeNode Node3_144 = new DefaultMutableTreeNode("医疗事故争议");
        DefaultMutableTreeNode Node3_145 = new DefaultMutableTreeNode("患者权益");
        DefaultMutableTreeNode Node3_146 = new DefaultMutableTreeNode("医护人员权益");
        DefaultMutableTreeNode Node3_147 = new DefaultMutableTreeNode("人口政策");
        DefaultMutableTreeNode Node3_148 = new DefaultMutableTreeNode("计划生育服务管理");
        DefaultMutableTreeNode Node3_149 = new DefaultMutableTreeNode("违法生育");
        DefaultMutableTreeNode Node3_150 = new DefaultMutableTreeNode("失独家庭");
        DefaultMutableTreeNode Node3_151 = new DefaultMutableTreeNode("独生子女服务奖励政策");
        DefaultMutableTreeNode Node3_152 = new DefaultMutableTreeNode("计生执法");
        DefaultMutableTreeNode Node3_153 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_154 = new DefaultMutableTreeNode("教育体制改革");
        DefaultMutableTreeNode Node3_155 = new DefaultMutableTreeNode("教育统筹安排");
        DefaultMutableTreeNode Node3_156 = new DefaultMutableTreeNode("教育资源配置");
        DefaultMutableTreeNode Node3_157 = new DefaultMutableTreeNode("异地升学");
        DefaultMutableTreeNode Node3_158 = new DefaultMutableTreeNode("招生政策");
        DefaultMutableTreeNode Node3_159 = new DefaultMutableTreeNode("考场考纪");
        DefaultMutableTreeNode Node3_160 = new DefaultMutableTreeNode("教学管理");
        DefaultMutableTreeNode Node3_161 = new DefaultMutableTreeNode("教育经费管理");
        DefaultMutableTreeNode Node3_162 = new DefaultMutableTreeNode("语言文字规范");
        DefaultMutableTreeNode Node3_163 = new DefaultMutableTreeNode("学历学位学籍管理");
        DefaultMutableTreeNode Node3_164 = new DefaultMutableTreeNode("学生负担");
        DefaultMutableTreeNode Node3_165 = new DefaultMutableTreeNode("民办学校");
        DefaultMutableTreeNode Node3_166 = new DefaultMutableTreeNode("校园安全");
        DefaultMutableTreeNode Node3_167 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_168 = new DefaultMutableTreeNode("师资力量");
        DefaultMutableTreeNode Node3_169 = new DefaultMutableTreeNode("工资福利");
        DefaultMutableTreeNode Node3_170 = new DefaultMutableTreeNode("企业学校");
        DefaultMutableTreeNode Node3_171 = new DefaultMutableTreeNode("民办代课教师");
        DefaultMutableTreeNode Node3_172 = new DefaultMutableTreeNode("教育救助");
        DefaultMutableTreeNode Node3_173 = new DefaultMutableTreeNode("希望工程");
        DefaultMutableTreeNode Node3_174 = new DefaultMutableTreeNode("收费标准");
        DefaultMutableTreeNode Node3_175 = new DefaultMutableTreeNode("乱收费");
        DefaultMutableTreeNode Node3_176 = new DefaultMutableTreeNode("文化体制改革");
        DefaultMutableTreeNode Node3_177 = new DefaultMutableTreeNode("文化市场与文化执法");
        DefaultMutableTreeNode Node3_178 = new DefaultMutableTreeNode("非物质文化遗产");
        DefaultMutableTreeNode Node3_179 = new DefaultMutableTreeNode("文化艺术");
        DefaultMutableTreeNode Node3_180 = new DefaultMutableTreeNode("公共文化");
        DefaultMutableTreeNode Node3_181 = new DefaultMutableTreeNode("网吧管理");
        DefaultMutableTreeNode Node3_182 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_183 = new DefaultMutableTreeNode("文物保护");
        DefaultMutableTreeNode Node3_184 = new DefaultMutableTreeNode("文物鉴定");
        DefaultMutableTreeNode Node3_185 = new DefaultMutableTreeNode("体育事业");
        DefaultMutableTreeNode Node3_186 = new DefaultMutableTreeNode("体育竞赛");
        DefaultMutableTreeNode Node3_187 = new DefaultMutableTreeNode("体育市场");
        DefaultMutableTreeNode Node3_188 = new DefaultMutableTreeNode("运动员权益");
        DefaultMutableTreeNode Node3_189 = new DefaultMutableTreeNode("幼儿园");
        DefaultMutableTreeNode Node3_190 = new DefaultMutableTreeNode("小学教育");
        DefaultMutableTreeNode Node3_191 = new DefaultMutableTreeNode("初中教育");
        DefaultMutableTreeNode Node3_192 = new DefaultMutableTreeNode("高中教育");
        DefaultMutableTreeNode Node3_193 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_194 = new DefaultMutableTreeNode("社区建设");
        DefaultMutableTreeNode Node3_195 = new DefaultMutableTreeNode("基层事务管理");
        DefaultMutableTreeNode Node3_196 = new DefaultMutableTreeNode("生活住房医疗");
        DefaultMutableTreeNode Node3_197 = new DefaultMutableTreeNode("评残及伤残抚恤");
        DefaultMutableTreeNode Node3_198 = new DefaultMutableTreeNode("参战退役人员待遇");
        DefaultMutableTreeNode Node3_199 = new DefaultMutableTreeNode("参试退役人员待遇");
        DefaultMutableTreeNode Node3_200 = new DefaultMutableTreeNode("老退役军人待遇");
//      DefaultMutableTreeNode Node3_451 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_201 = new DefaultMutableTreeNode("转业退伍安置");
        DefaultMutableTreeNode Node3_202 = new DefaultMutableTreeNode("军休安置");
        DefaultMutableTreeNode Node3_203 = new DefaultMutableTreeNode("复原干部安置");
        DefaultMutableTreeNode Node3_204 = new DefaultMutableTreeNode("农村低保");
        DefaultMutableTreeNode Node3_205 = new DefaultMutableTreeNode("城镇低保");
        DefaultMutableTreeNode Node3_206 = new DefaultMutableTreeNode("医疗救助");
        DefaultMutableTreeNode Node3_207 = new DefaultMutableTreeNode("特困人员供养");
        DefaultMutableTreeNode Node3_208 = new DefaultMutableTreeNode("救助站、儿童福利院");
//      DefaultMutableTreeNode Node3_452 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_209 = new DefaultMutableTreeNode("区划调整");
        DefaultMutableTreeNode Node3_210 = new DefaultMutableTreeNode("地名管理");
        DefaultMutableTreeNode Node3_211 = new DefaultMutableTreeNode("边界纠纷");
        DefaultMutableTreeNode Node3_212 = new DefaultMutableTreeNode("社团登记");
        DefaultMutableTreeNode Node3_213 = new DefaultMutableTreeNode("社团管理");
        DefaultMutableTreeNode Node3_214 = new DefaultMutableTreeNode("救灾管理");
        DefaultMutableTreeNode Node3_215 = new DefaultMutableTreeNode("捐赠服务");
        DefaultMutableTreeNode Node3_216 = new DefaultMutableTreeNode("福利事业");
        DefaultMutableTreeNode Node3_217 = new DefaultMutableTreeNode("慈善救助");
        DefaultMutableTreeNode Node3_218 = new DefaultMutableTreeNode("婚姻登记");
        DefaultMutableTreeNode Node3_219 = new DefaultMutableTreeNode("殡葬管理");
        DefaultMutableTreeNode Node3_220 = new DefaultMutableTreeNode("收养登记");
        DefaultMutableTreeNode Node3_221 = new DefaultMutableTreeNode("生活无着人员救助");
        DefaultMutableTreeNode Node3_222 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_223 = new DefaultMutableTreeNode("立法规划");
        DefaultMutableTreeNode Node3_224 = new DefaultMutableTreeNode("法制宣传");
        DefaultMutableTreeNode Node3_225 = new DefaultMutableTreeNode("司法改革");
        DefaultMutableTreeNode Node3_226 = new DefaultMutableTreeNode("刑事诉讼");
        DefaultMutableTreeNode Node3_227 = new DefaultMutableTreeNode("民事诉讼");
        DefaultMutableTreeNode Node3_228 = new DefaultMutableTreeNode("行政诉讼");
        DefaultMutableTreeNode Node3_229 = new DefaultMutableTreeNode("民商事仲裁");
        DefaultMutableTreeNode Node3_230 = new DefaultMutableTreeNode("劳动仲裁");
        DefaultMutableTreeNode Node3_231 = new DefaultMutableTreeNode("人事仲裁");
        DefaultMutableTreeNode Node3_232 = new DefaultMutableTreeNode("司法调解");
        DefaultMutableTreeNode Node3_233 = new DefaultMutableTreeNode("生效法律文书执行");
        DefaultMutableTreeNode Node3_234 = new DefaultMutableTreeNode("复议申请");
        DefaultMutableTreeNode Node3_235 = new DefaultMutableTreeNode("不服决定");
        DefaultMutableTreeNode Node3_236 = new DefaultMutableTreeNode("决定执行");
        DefaultMutableTreeNode Node3_237 = new DefaultMutableTreeNode("司法鉴定");
        DefaultMutableTreeNode Node3_238 = new DefaultMutableTreeNode("公证");
        DefaultMutableTreeNode Node3_239 = new DefaultMutableTreeNode("律师");
        DefaultMutableTreeNode Node3_240 = new DefaultMutableTreeNode("法律援助");
        DefaultMutableTreeNode Node3_241 = new DefaultMutableTreeNode("监狱管理");
        DefaultMutableTreeNode Node3_242 = new DefaultMutableTreeNode("社区矫正");
        DefaultMutableTreeNode Node3_243 = new DefaultMutableTreeNode("刑事讯逼供");
        DefaultMutableTreeNode Node3_244 = new DefaultMutableTreeNode("超期羁押");
        DefaultMutableTreeNode Node3_245 = new DefaultMutableTreeNode("警务执法");
        DefaultMutableTreeNode Node3_246 = new DefaultMutableTreeNode("包庇违法违纪人员");
        DefaultMutableTreeNode Node3_247 = new DefaultMutableTreeNode("治安案件");
        DefaultMutableTreeNode Node3_248 = new DefaultMutableTreeNode("天网");
        DefaultMutableTreeNode Node3_249 = new DefaultMutableTreeNode("打黑除恶");
        DefaultMutableTreeNode Node3_250 = new DefaultMutableTreeNode("黄赌毒");
        DefaultMutableTreeNode Node3_251 = new DefaultMutableTreeNode("走私贩私");
        DefaultMutableTreeNode Node3_252 = new DefaultMutableTreeNode("拐卖人口");
        DefaultMutableTreeNode Node3_253 = new DefaultMutableTreeNode("消防安全");
        DefaultMutableTreeNode Node3_254 = new DefaultMutableTreeNode("邪教组织");
        DefaultMutableTreeNode Node3_255 = new DefaultMutableTreeNode("集会游行示威");
        DefaultMutableTreeNode Node3_256 = new DefaultMutableTreeNode("防范打击恐怖活动");
        DefaultMutableTreeNode Node3_257 = new DefaultMutableTreeNode("交通安全管理");
        DefaultMutableTreeNode Node3_258 = new DefaultMutableTreeNode("交通信号、交通标识管理");
        DefaultMutableTreeNode Node3_259 = new DefaultMutableTreeNode("占道停车");
        DefaultMutableTreeNode Node3_260 = new DefaultMutableTreeNode("交通拥堵");
        DefaultMutableTreeNode Node3_261 = new DefaultMutableTreeNode("五路一桥");
        DefaultMutableTreeNode Node3_262 = new DefaultMutableTreeNode("车辆驾照管理");
        DefaultMutableTreeNode Node3_263 = new DefaultMutableTreeNode("驾校管理");
        DefaultMutableTreeNode Node3_264 = new DefaultMutableTreeNode("市属高速公路管理与维护");
        DefaultMutableTreeNode Node3_265 = new DefaultMutableTreeNode("立案侦查");
        DefaultMutableTreeNode Node3_266 = new DefaultMutableTreeNode("强制措施");
        DefaultMutableTreeNode Node3_267 = new DefaultMutableTreeNode("案件侦破");
        DefaultMutableTreeNode Node3_268 = new DefaultMutableTreeNode("黄赌毒");
        DefaultMutableTreeNode Node3_269 = new DefaultMutableTreeNode("街道门牌号编制、路牌设置");
        DefaultMutableTreeNode Node3_270 = new DefaultMutableTreeNode("户籍管理");
        DefaultMutableTreeNode Node3_271 = new DefaultMutableTreeNode("身份证管理");
        DefaultMutableTreeNode Node3_272 = new DefaultMutableTreeNode("流动人口管理");
        DefaultMutableTreeNode Node3_273 = new DefaultMutableTreeNode("出入境管理");
        DefaultMutableTreeNode Node3_274 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_275 = new DefaultMutableTreeNode("经济体制改革");
        DefaultMutableTreeNode Node3_276 = new DefaultMutableTreeNode("产业行业政策");
        DefaultMutableTreeNode Node3_277 = new DefaultMutableTreeNode("区域发展");
        DefaultMutableTreeNode Node3_278 = new DefaultMutableTreeNode("收入分配");
        DefaultMutableTreeNode Node3_279 = new DefaultMutableTreeNode("金融管理");
        DefaultMutableTreeNode Node3_280 = new DefaultMutableTreeNode("财政收支");
        DefaultMutableTreeNode Node3_281 = new DefaultMutableTreeNode("税收征管");
        DefaultMutableTreeNode Node3_282 = new DefaultMutableTreeNode("集资融资");
        DefaultMutableTreeNode Node3_283 = new DefaultMutableTreeNode("保险业监管");
        DefaultMutableTreeNode Node3_284 = new DefaultMutableTreeNode("证券业监管");
        DefaultMutableTreeNode Node3_285 = new DefaultMutableTreeNode("期货基金");
        DefaultMutableTreeNode Node3_286 = new DefaultMutableTreeNode("企业改制");
        DefaultMutableTreeNode Node3_287 = new DefaultMutableTreeNode("企业兼并重组");
        DefaultMutableTreeNode Node3_288 = new DefaultMutableTreeNode("资产流失");
        DefaultMutableTreeNode Node3_289 = new DefaultMutableTreeNode("能源开发供应");
        DefaultMutableTreeNode Node3_290 = new DefaultMutableTreeNode("加油站、加气站");
        DefaultMutableTreeNode Node3_291 = new DefaultMutableTreeNode("节能降耗");
        DefaultMutableTreeNode Node3_292 = new DefaultMutableTreeNode("新能源产品研发与推广");
        DefaultMutableTreeNode Node3_293 = new DefaultMutableTreeNode("政策性破产");
        DefaultMutableTreeNode Node3_294 = new DefaultMutableTreeNode("依法破产");
        DefaultMutableTreeNode Node3_295 = new DefaultMutableTreeNode("安全生产管理");
        DefaultMutableTreeNode Node3_296 = new DefaultMutableTreeNode("安全隐患");
        DefaultMutableTreeNode Node3_297 = new DefaultMutableTreeNode("事故处理");
        DefaultMutableTreeNode Node3_298 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_299 = new DefaultMutableTreeNode("规划建设");
        DefaultMutableTreeNode Node3_300 = new DefaultMutableTreeNode("设施维护");
        DefaultMutableTreeNode Node3_301 = new DefaultMutableTreeNode("规费征嵇");
        DefaultMutableTreeNode Node3_302 = new DefaultMutableTreeNode("公路收费");
        DefaultMutableTreeNode Node3_303 = new DefaultMutableTreeNode("运营权管理");
        DefaultMutableTreeNode Node3_304 = new DefaultMutableTreeNode("旅客运输");
        DefaultMutableTreeNode Node3_305 = new DefaultMutableTreeNode("货物运输");
        DefaultMutableTreeNode Node3_306 = new DefaultMutableTreeNode("物流管理");
        DefaultMutableTreeNode Node3_307 = new DefaultMutableTreeNode("网约车、共享车辆管理");
        DefaultMutableTreeNode Node3_308 = new DefaultMutableTreeNode("公交车管理");
        DefaultMutableTreeNode Node3_309 = new DefaultMutableTreeNode("地铁管理");
        DefaultMutableTreeNode Node3_310 = new DefaultMutableTreeNode("运输安全");
        DefaultMutableTreeNode Node3_311 = new DefaultMutableTreeNode("邮政行业规划");
        DefaultMutableTreeNode Node3_312 = new DefaultMutableTreeNode("邮政市场监管");
        DefaultMutableTreeNode Node3_313 = new DefaultMutableTreeNode("快递市场管理");
        DefaultMutableTreeNode Node3_314 = new DefaultMutableTreeNode("经营权转让");
        DefaultMutableTreeNode Node3_315 = new DefaultMutableTreeNode("运价监管");
        DefaultMutableTreeNode Node3_316 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_317 = new DefaultMutableTreeNode("贸易发展战略");
        DefaultMutableTreeNode Node3_318 = new DefaultMutableTreeNode("市场垄断");
        DefaultMutableTreeNode Node3_319 = new DefaultMutableTreeNode("劳务输出");
        DefaultMutableTreeNode Node3_320 = new DefaultMutableTreeNode("反倾销");
        DefaultMutableTreeNode Node3_321 = new DefaultMutableTreeNode("出入口管理");
        DefaultMutableTreeNode Node3_322 = new DefaultMutableTreeNode("不正当竞争");
        DefaultMutableTreeNode Node3_323 = new DefaultMutableTreeNode("传销");
        DefaultMutableTreeNode Node3_324 = new DefaultMutableTreeNode("直销");
        DefaultMutableTreeNode Node3_325 = new DefaultMutableTreeNode("营业执照、企业年报等");
        DefaultMutableTreeNode Node3_326 = new DefaultMutableTreeNode("企业信息（企业信用网等）");
        DefaultMutableTreeNode Node3_327 = new DefaultMutableTreeNode("消费纠纷");
        DefaultMutableTreeNode Node3_328 = new DefaultMutableTreeNode("广告监督");
        DefaultMutableTreeNode Node3_329 = new DefaultMutableTreeNode("商标管理");
        DefaultMutableTreeNode Node3_330 = new DefaultMutableTreeNode("商品质量");
        DefaultMutableTreeNode Node3_331 = new DefaultMutableTreeNode("安全生产综合监督管理");
        DefaultMutableTreeNode Node3_332 = new DefaultMutableTreeNode("烟花爆竹生产、售卖点的设置");
        DefaultMutableTreeNode Node3_333 = new DefaultMutableTreeNode("烟草管理");
        DefaultMutableTreeNode Node3_334 = new DefaultMutableTreeNode("中介机构管理");
        DefaultMutableTreeNode Node3_335 = new DefaultMutableTreeNode("物价监管");
        DefaultMutableTreeNode Node3_336 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_337 = new DefaultMutableTreeNode("产品质量监控");
        DefaultMutableTreeNode Node3_338 = new DefaultMutableTreeNode("特种设备管理");
        DefaultMutableTreeNode Node3_339 = new DefaultMutableTreeNode("认证认可标准化");
        DefaultMutableTreeNode Node3_340 = new DefaultMutableTreeNode("出入境检验检疫");
        DefaultMutableTreeNode Node3_341 = new DefaultMutableTreeNode("旅游市场管理");
        DefaultMutableTreeNode Node3_342 = new DefaultMutableTreeNode("酒店管理");
        DefaultMutableTreeNode Node3_343 = new DefaultMutableTreeNode("景区管理");
        DefaultMutableTreeNode Node3_344 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_345 = new DefaultMutableTreeNode("发展规划");
        DefaultMutableTreeNode Node3_346 = new DefaultMutableTreeNode("成果鉴定转化");
        DefaultMutableTreeNode Node3_347 = new DefaultMutableTreeNode("知识产权申报");
        DefaultMutableTreeNode Node3_348 = new DefaultMutableTreeNode("知识产权保护");
        DefaultMutableTreeNode Node3_349 = new DefaultMutableTreeNode("信息化产业发展规划");
        DefaultMutableTreeNode Node3_350 = new DefaultMutableTreeNode("软件行业管理");
        DefaultMutableTreeNode Node3_351 = new DefaultMutableTreeNode("互联网运营管理");
        DefaultMutableTreeNode Node3_352 = new DefaultMutableTreeNode("电信宽带");
        DefaultMutableTreeNode Node3_353 = new DefaultMutableTreeNode("通信保障");
        DefaultMutableTreeNode Node3_354 = new DefaultMutableTreeNode("运营商监管");
        DefaultMutableTreeNode Node3_355 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_356 = new DefaultMutableTreeNode("水污染");
        DefaultMutableTreeNode Node3_357 = new DefaultMutableTreeNode("光污染");
        DefaultMutableTreeNode Node3_358 = new DefaultMutableTreeNode("大气污染");
        DefaultMutableTreeNode Node3_359 = new DefaultMutableTreeNode("固体污染");
        DefaultMutableTreeNode Node3_360 = new DefaultMutableTreeNode("噪音污染");
        DefaultMutableTreeNode Node3_361 = new DefaultMutableTreeNode("危险化学品污染");
        DefaultMutableTreeNode Node3_362 = new DefaultMutableTreeNode("放射性污染");
        DefaultMutableTreeNode Node3_363 = new DefaultMutableTreeNode("电磁污染");
        DefaultMutableTreeNode Node3_364 = new DefaultMutableTreeNode("生态破坏");
        DefaultMutableTreeNode Node3_365 = new DefaultMutableTreeNode("其他污染");
        DefaultMutableTreeNode Node3_366 = new DefaultMutableTreeNode("未批先建");
        DefaultMutableTreeNode Node3_367 = new DefaultMutableTreeNode("未验先用");
        DefaultMutableTreeNode Node3_368 = new DefaultMutableTreeNode("环保报告不实");
        DefaultMutableTreeNode Node3_369 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_370 = new DefaultMutableTreeNode("环境资源管理");
        DefaultMutableTreeNode Node3_371 = new DefaultMutableTreeNode("生态示范和模范城区建设");
        DefaultMutableTreeNode Node3_372 = new DefaultMutableTreeNode("环境检测");
        DefaultMutableTreeNode Node3_373 = new DefaultMutableTreeNode("环境执法");
        DefaultMutableTreeNode Node3_374 = new DefaultMutableTreeNode("污染损害纠纷调解");
        DefaultMutableTreeNode Node3_375 = new DefaultMutableTreeNode("专项资金使用");
        DefaultMutableTreeNode Node3_376 = new DefaultMutableTreeNode("淘汰落后产能");
        DefaultMutableTreeNode Node3_377 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_378 = new DefaultMutableTreeNode("制度建设");
        DefaultMutableTreeNode Node3_379 = new DefaultMutableTreeNode("组织建设");
        DefaultMutableTreeNode Node3_380 = new DefaultMutableTreeNode("作风建设");
        DefaultMutableTreeNode Node3_381 = new DefaultMutableTreeNode("廉政建设");
        DefaultMutableTreeNode Node3_382 = new DefaultMutableTreeNode("政治体制改革");
        DefaultMutableTreeNode Node3_383 = new DefaultMutableTreeNode("人大工作");
        DefaultMutableTreeNode Node3_384 = new DefaultMutableTreeNode("政协工作");
        DefaultMutableTreeNode Node3_385 = new DefaultMutableTreeNode("统战工作");
        DefaultMutableTreeNode Node3_386 = new DefaultMutableTreeNode("民族政策");
        DefaultMutableTreeNode Node3_387 = new DefaultMutableTreeNode("民族事务");
        DefaultMutableTreeNode Node3_388 = new DefaultMutableTreeNode("宗教事务");
        DefaultMutableTreeNode Node3_389 = new DefaultMutableTreeNode("港澳事物");
        DefaultMutableTreeNode Node3_390 = new DefaultMutableTreeNode("台湾事务");
        DefaultMutableTreeNode Node3_391 = new DefaultMutableTreeNode("侨务");
        DefaultMutableTreeNode Node3_392 = new DefaultMutableTreeNode("外交事务");
        DefaultMutableTreeNode Node3_393 = new DefaultMutableTreeNode("军事国防");
        DefaultMutableTreeNode Node3_394 = new DefaultMutableTreeNode("工会工作");
        DefaultMutableTreeNode Node3_395 = new DefaultMutableTreeNode("共青团工作");
        DefaultMutableTreeNode Node3_396 = new DefaultMutableTreeNode("妇联工作");
        DefaultMutableTreeNode Node3_397 = new DefaultMutableTreeNode("精神文明建设");
        DefaultMutableTreeNode Node3_398 = new DefaultMutableTreeNode("广播影视管理");
        DefaultMutableTreeNode Node3_399 = new DefaultMutableTreeNode("新闻管理");
        DefaultMutableTreeNode Node3_400 = new DefaultMutableTreeNode("出版管理");
        DefaultMutableTreeNode Node3_401 = new DefaultMutableTreeNode("互联网信息管理");
        DefaultMutableTreeNode Node3_402 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_403 = new DefaultMutableTreeNode("跑官要官");
        DefaultMutableTreeNode Node3_404 = new DefaultMutableTreeNode("任人唯亲");
        DefaultMutableTreeNode Node3_405 = new DefaultMutableTreeNode("干部任免");
        DefaultMutableTreeNode Node3_406 = new DefaultMutableTreeNode("职务升降");
        DefaultMutableTreeNode Node3_407 = new DefaultMutableTreeNode("招聘录用");
        DefaultMutableTreeNode Node3_408 = new DefaultMutableTreeNode("辞退");
        DefaultMutableTreeNode Node3_409 = new DefaultMutableTreeNode("编制管理");
        DefaultMutableTreeNode Node3_410 = new DefaultMutableTreeNode("职位管理");
        DefaultMutableTreeNode Node3_411 = new DefaultMutableTreeNode("人才战略");
        DefaultMutableTreeNode Node3_412 = new DefaultMutableTreeNode("人才市场管理");
        DefaultMutableTreeNode Node3_413 = new DefaultMutableTreeNode("职称评定");
        DefaultMutableTreeNode Node3_414 = new DefaultMutableTreeNode("专业资格考试");
        DefaultMutableTreeNode Node3_415 = new DefaultMutableTreeNode("职业资格考试");
        DefaultMutableTreeNode Node3_416 = new DefaultMutableTreeNode("计划安置");
        DefaultMutableTreeNode Node3_417 = new DefaultMutableTreeNode("自助择业");
        DefaultMutableTreeNode Node3_418 = new DefaultMutableTreeNode("企业军转干部");
        DefaultMutableTreeNode Node3_419 = new DefaultMutableTreeNode("机构改革");
        DefaultMutableTreeNode Node3_420 = new DefaultMutableTreeNode("行政机构改革");
        DefaultMutableTreeNode Node3_421 = new DefaultMutableTreeNode("事业单位改制");
        DefaultMutableTreeNode Node3_422 = new DefaultMutableTreeNode("乡镇机构改革");
        DefaultMutableTreeNode Node3_423 = new DefaultMutableTreeNode("离休");
        DefaultMutableTreeNode Node3_424 = new DefaultMutableTreeNode("离休待遇");
        DefaultMutableTreeNode Node3_425 = new DefaultMutableTreeNode("退改离");
        DefaultMutableTreeNode Node3_426 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_427 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_428 = new DefaultMutableTreeNode("贪污");
        DefaultMutableTreeNode Node3_429 = new DefaultMutableTreeNode("行贿受贿索贿");
        DefaultMutableTreeNode Node3_430 = new DefaultMutableTreeNode("挪用公款");
        DefaultMutableTreeNode Node3_431 = new DefaultMutableTreeNode("买官卖官");
        DefaultMutableTreeNode Node3_432 = new DefaultMutableTreeNode("财产来源不明");
        DefaultMutableTreeNode Node3_433 = new DefaultMutableTreeNode("以权谋私");
        DefaultMutableTreeNode Node3_434 = new DefaultMutableTreeNode("打击报复");
        DefaultMutableTreeNode Node3_435 = new DefaultMutableTreeNode("玩忽职守");
        DefaultMutableTreeNode Node3_436 = new DefaultMutableTreeNode("包庇纵容");
        DefaultMutableTreeNode Node3_437 = new DefaultMutableTreeNode("形式主义");
        DefaultMutableTreeNode Node3_438 = new DefaultMutableTreeNode("官僚主义");
        DefaultMutableTreeNode Node3_439 = new DefaultMutableTreeNode("享乐主义");
        DefaultMutableTreeNode Node3_440 = new DefaultMutableTreeNode("奢靡之风");
        DefaultMutableTreeNode Node3_441 = new DefaultMutableTreeNode("党纪处分");
        DefaultMutableTreeNode Node3_442 = new DefaultMutableTreeNode("政纪处分");
        DefaultMutableTreeNode Node3_443 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_444 = new DefaultMutableTreeNode("私房落实政策");
        DefaultMutableTreeNode Node3_445 = new DefaultMutableTreeNode("平反落实政策");
        DefaultMutableTreeNode Node3_446 = new DefaultMutableTreeNode("支边知青");
        DefaultMutableTreeNode Node3_447 = new DefaultMutableTreeNode("精神下放");
        DefaultMutableTreeNode Node3_448 = new DefaultMutableTreeNode("无效来电");
        DefaultMutableTreeNode Node3_449 = new DefaultMutableTreeNode("无效来信");
        DefaultMutableTreeNode Node3_450 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_451 = new DefaultMutableTreeNode("其他");
        DefaultMutableTreeNode Node3_452 = new DefaultMutableTreeNode("其他");
        
        // 把三级节点作为子节点添加到相应的二级节点
        Node2_1.add(Node3_1);
        Node2_1.add(Node3_2);
        Node2_1.add(Node3_3);
        Node2_1.add(Node3_4);
        Node2_2.add(Node3_5);
        Node2_2.add(Node3_6);
        Node2_2.add(Node3_7);
        Node2_3.add(Node3_8);
        Node2_3.add(Node3_9);
        Node2_4.add(Node3_10);
        Node2_4.add(Node3_11);
        Node2_4.add(Node3_12);
        Node2_4.add(Node3_13);
        Node2_4.add(Node3_14);
        Node2_4.add(Node3_15);
        Node2_5.add(Node3_16);
        Node2_5.add(Node3_17);
        Node2_6.add(Node3_18);
        Node2_6.add(Node3_19);
        Node2_7.add(Node3_20);
        Node2_7.add(Node3_21);
        Node2_8.add(Node3_22);
        Node2_8.add(Node3_23);
        Node2_8.add(Node3_24);
        Node2_8.add(Node3_25);
        Node2_8.add(Node3_26);
        Node2_8.add(Node3_27);
        Node2_9.add(Node3_28);
        Node2_9.add(Node3_29);
        Node2_10.add(Node3_30);
        Node2_10.add(Node3_31);
        Node2_10.add(Node3_32);
        Node2_10.add(Node3_33);
        Node2_10.add(Node3_34);
        Node2_10.add(Node3_35);
        Node2_10.add(Node3_36);
        Node2_10.add(Node3_37);
        Node2_10.add(Node3_38);
        Node2_11.add(Node3_39);
        Node2_11.add(Node3_40);
        Node2_12.add(Node3_41);
        Node2_12.add(Node3_42);
        Node2_12.add(Node3_43);
        Node2_12.add(Node3_44);
        Node2_13.add(Node3_45);
        Node2_13.add(Node3_46);
        Node2_14.add(Node3_47);
        Node2_14.add(Node3_48);
        Node2_14.add(Node3_49);
        Node2_14.add(Node3_50);
        Node2_14.add(Node3_51);
        Node2_15.add(Node3_52);
        Node2_15.add(Node3_53);
        Node2_16.add(Node3_54);
        Node2_16.add(Node3_55);
        Node2_16.add(Node3_56);
        Node2_17.add(Node3_57);
        Node2_17.add(Node3_58);
        Node2_18.add(Node3_59);
        Node2_19.add(Node3_60);
        Node2_19.add(Node3_61);
        Node2_19.add(Node3_62);
        Node2_19.add(Node3_63);
        Node2_20.add(Node3_64);
        Node2_20.add(Node3_65);
        Node2_20.add(Node3_66);
        Node2_20.add(Node3_67);
        Node2_20.add(Node3_68);
        Node2_20.add(Node3_69);
        Node2_20.add(Node3_70);
        Node2_20.add(Node3_71);
        Node2_20.add(Node3_72);
        Node2_20.add(Node3_73);
        Node2_21.add(Node3_74);
        Node2_21.add(Node3_75);
        Node2_21.add(Node3_76);
        Node2_21.add(Node3_77);
        Node2_21.add(Node3_78);
        Node2_22.add(Node3_79);
        Node2_22.add(Node3_80);
        Node2_22.add(Node3_81);
        Node2_22.add(Node3_82);
        Node2_22.add(Node3_83);
        Node2_22.add(Node3_84);
        Node2_22.add(Node3_85);
        Node2_22.add(Node3_86);
        Node2_22.add(Node3_87);
        Node2_23.add(Node3_88);
        Node2_23.add(Node3_89);
        Node2_23.add(Node3_90);
        Node2_23.add(Node3_91);
        Node2_24.add(Node3_92);
        Node2_24.add(Node3_93);
        Node2_24.add(Node3_94);
        Node2_25.add(Node3_95);
        Node2_25.add(Node3_96);
        Node2_26.add(Node3_97);
        Node2_27.add(Node3_98);
        Node2_27.add(Node3_99);
        Node2_27.add(Node3_100);
        Node2_27.add(Node3_101);
        Node2_27.add(Node3_102);
        Node2_28.add(Node3_103);
        Node2_28.add(Node3_104);
        Node2_28.add(Node3_105);
        Node2_28.add(Node3_106);
        Node2_29.add(Node3_107);
        Node2_30.add(Node3_108);
        Node2_30.add(Node3_109);
        Node2_30.add(Node3_110);
        Node2_30.add(Node3_111);
        Node2_30.add(Node3_112);
        Node2_31.add(Node3_113);
        Node2_31.add(Node3_114);
        Node2_31.add(Node3_115);
        Node2_32.add(Node3_116);
        Node2_32.add(Node3_117);
        Node2_32.add(Node3_118);
        Node2_32.add(Node3_119);
        Node2_33.add(Node3_120);
        Node2_33.add(Node3_121);
        Node2_33.add(Node3_122);
        Node2_33.add(Node3_123);
        Node2_33.add(Node3_124);
        Node2_34.add(Node3_125);
        Node2_34.add(Node3_126);
        Node2_34.add(Node3_127);
        Node2_34.add(Node3_128);
        Node2_34.add(Node3_129);
        Node2_35.add(Node3_130);
        Node2_36.add(Node3_131);
        Node2_36.add(Node3_132);
        Node2_36.add(Node3_133);
        Node2_37.add(Node3_134);
        Node2_37.add(Node3_135);
        Node2_37.add(Node3_136);
        Node2_38.add(Node3_137);
        Node2_38.add(Node3_138);
        Node2_38.add(Node3_139);
        Node2_38.add(Node3_140);
        Node2_38.add(Node3_141);
        Node2_38.add(Node3_142);
        Node2_38.add(Node3_143);
        Node2_39.add(Node3_144);
        Node2_39.add(Node3_145);
        Node2_39.add(Node3_146);
        Node2_40.add(Node3_147);
        Node2_40.add(Node3_148);
        Node2_40.add(Node3_149);
        Node2_40.add(Node3_150);
        Node2_40.add(Node3_151);
        Node2_40.add(Node3_152);
        Node2_41.add(Node3_153);
        Node2_42.add(Node3_154);
        Node2_42.add(Node3_155);
        Node2_42.add(Node3_156);
        Node2_42.add(Node3_157);
        Node2_43.add(Node3_158);
        Node2_43.add(Node3_159);
        Node2_44.add(Node3_160);
        Node2_44.add(Node3_161);
        Node2_44.add(Node3_162);
        Node2_44.add(Node3_163);
        Node2_44.add(Node3_164);
        Node2_44.add(Node3_165);
        Node2_44.add(Node3_166);
        Node2_44.add(Node3_167);
        Node2_45.add(Node3_168);
        Node2_45.add(Node3_169);
        Node2_45.add(Node3_170);
        Node2_45.add(Node3_171);
        Node2_46.add(Node3_172);
        Node2_46.add(Node3_173);
        Node2_46.add(Node3_174);
        Node2_46.add(Node3_175);
        Node2_47.add(Node3_176);
        Node2_47.add(Node3_177);
        Node2_47.add(Node3_178);
        Node2_47.add(Node3_179);
        Node2_47.add(Node3_180);
        Node2_47.add(Node3_181);
        Node2_47.add(Node3_182);
        Node2_48.add(Node3_183);
        Node2_48.add(Node3_184);
        Node2_49.add(Node3_185);
        Node2_49.add(Node3_186);
        Node2_49.add(Node3_187);
        Node2_49.add(Node3_188);
        Node2_50.add(Node3_189);
        Node2_50.add(Node3_190);
        Node2_50.add(Node3_191);
        Node2_50.add(Node3_192);
        Node2_51.add(Node3_193);
        Node2_52.add(Node3_194);
        Node2_52.add(Node3_195);
        Node2_53.add(Node3_196);
        Node2_53.add(Node3_197);
        Node2_53.add(Node3_198);
        Node2_53.add(Node3_199);
        Node2_53.add(Node3_200);
        Node2_53.add(Node3_451);
        Node2_54.add(Node3_201);
        Node2_54.add(Node3_202);
        Node2_54.add(Node3_203);
        Node2_55.add(Node3_204);
        Node2_55.add(Node3_205);
        Node2_55.add(Node3_206);
        Node2_55.add(Node3_207);
        Node2_55.add(Node3_208);
        Node2_55.add(Node3_452);
        Node2_56.add(Node3_209);
        Node2_56.add(Node3_210);
        Node2_56.add(Node3_211);
        Node2_57.add(Node3_212);
        Node2_57.add(Node3_213);
        Node2_58.add(Node3_214);
        Node2_58.add(Node3_215);
        Node2_59.add(Node3_216);
        Node2_59.add(Node3_217);
        Node2_60.add(Node3_218);
        Node2_60.add(Node3_219);
        Node2_60.add(Node3_220);
        Node2_60.add(Node3_221);
        Node2_61.add(Node3_222);
        Node2_62.add(Node3_223);
        Node2_62.add(Node3_224);
        Node2_62.add(Node3_225);
        Node2_63.add(Node3_226);
        Node2_63.add(Node3_227);
        Node2_63.add(Node3_228);
        Node2_64.add(Node3_229);
        Node2_64.add(Node3_230);
        Node2_64.add(Node3_231);
        Node2_64.add(Node3_232);
        Node2_64.add(Node3_233);
        Node2_65.add(Node3_234);
        Node2_65.add(Node3_235);
        Node2_65.add(Node3_236);
        Node2_66.add(Node3_237);
        Node2_66.add(Node3_238);
        Node2_66.add(Node3_239);
        Node2_66.add(Node3_240);
        Node2_67.add(Node3_241);
        Node2_67.add(Node3_242);
        Node2_68.add(Node3_243);
        Node2_68.add(Node3_244);
        Node2_68.add(Node3_245);
        Node2_68.add(Node3_246);
        Node2_69.add(Node3_247);
        Node2_69.add(Node3_248);
        Node2_69.add(Node3_249);
        Node2_69.add(Node3_250);
        Node2_69.add(Node3_251);
        Node2_69.add(Node3_252);
        Node2_69.add(Node3_253);
        Node2_69.add(Node3_254);
        Node2_69.add(Node3_255);
        Node2_69.add(Node3_256);
        Node2_70.add(Node3_257);
        Node2_70.add(Node3_258);
        Node2_70.add(Node3_259);
        Node2_70.add(Node3_260);
        Node2_70.add(Node3_261);
        Node2_70.add(Node3_262);
        Node2_70.add(Node3_263);
        Node2_70.add(Node3_264);
        Node2_71.add(Node3_265);
        Node2_71.add(Node3_266);
        Node2_71.add(Node3_267);
        Node2_71.add(Node3_268);
        Node2_72.add(Node3_269);
        Node2_72.add(Node3_270);
        Node2_72.add(Node3_271);
        Node2_72.add(Node3_272);
        Node2_72.add(Node3_273);
        Node2_73.add(Node3_274);
        Node2_74.add(Node3_275);
        Node2_74.add(Node3_276);
        Node2_74.add(Node3_277);
        Node2_74.add(Node3_278);
        Node2_75.add(Node3_279);
        Node2_75.add(Node3_280);
        Node2_75.add(Node3_281);
        Node2_75.add(Node3_282);
        Node2_76.add(Node3_283);
        Node2_76.add(Node3_284);
        Node2_76.add(Node3_285);
        Node2_77.add(Node3_286);
        Node2_77.add(Node3_287);
        Node2_77.add(Node3_288);
        Node2_78.add(Node3_289);
        Node2_78.add(Node3_290);
        Node2_78.add(Node3_291);
        Node2_78.add(Node3_292);
        Node2_79.add(Node3_293);
        Node2_79.add(Node3_294);
        Node2_80.add(Node3_295);
        Node2_80.add(Node3_296);
        Node2_80.add(Node3_297);
        Node2_81.add(Node3_298);
        Node2_82.add(Node3_299);
        Node2_82.add(Node3_300);
        Node2_82.add(Node3_301);
        Node2_82.add(Node3_302);
        Node2_82.add(Node3_303);
        Node2_83.add(Node3_304);
        Node2_83.add(Node3_305);
        Node2_83.add(Node3_306);
        Node2_83.add(Node3_307);
        Node2_83.add(Node3_308);
        Node2_83.add(Node3_309);
        Node2_83.add(Node3_310);
        Node2_84.add(Node3_311);
        Node2_84.add(Node3_312);
        Node2_84.add(Node3_313);
        Node2_85.add(Node3_314);
        Node2_85.add(Node3_315);
        Node2_86.add(Node3_316);
        Node2_87.add(Node3_317);
        Node2_87.add(Node3_318);
        Node2_87.add(Node3_319);
        Node2_87.add(Node3_320);
        Node2_87.add(Node3_321);
        Node2_88.add(Node3_322);
        Node2_88.add(Node3_323);
        Node2_88.add(Node3_324);
        Node2_88.add(Node3_325);
        Node2_88.add(Node3_326);
        Node2_88.add(Node3_327);
        Node2_88.add(Node3_328);
        Node2_88.add(Node3_329);
        Node2_88.add(Node3_330);
        Node2_88.add(Node3_331);
        Node2_88.add(Node3_332);
        Node2_88.add(Node3_333);
        Node2_88.add(Node3_334);
        Node2_88.add(Node3_335);
        Node2_88.add(Node3_336);
        Node2_89.add(Node3_337);
        Node2_89.add(Node3_338);
        Node2_89.add(Node3_339);
        Node2_89.add(Node3_340);
        Node2_90.add(Node3_341);
        Node2_90.add(Node3_342);
        Node2_90.add(Node3_343);
        Node2_91.add(Node3_344);
        Node2_92.add(Node3_345);
        Node2_92.add(Node3_346);
        Node2_93.add(Node3_347);
        Node2_93.add(Node3_348);
        Node2_94.add(Node3_349);
        Node2_94.add(Node3_350);
        Node2_94.add(Node3_351);
        Node2_95.add(Node3_352);
        Node2_95.add(Node3_353);
        Node2_95.add(Node3_354);
        Node2_96.add(Node3_355);
        Node2_97.add(Node3_356);
        Node2_97.add(Node3_357);
        Node2_97.add(Node3_358);
        Node2_97.add(Node3_359);
        Node2_97.add(Node3_360);
        Node2_97.add(Node3_361);
        Node2_97.add(Node3_362);
        Node2_97.add(Node3_363);
        Node2_97.add(Node3_364);
        Node2_97.add(Node3_365);
        Node2_98.add(Node3_366);
        Node2_98.add(Node3_367);
        Node2_98.add(Node3_368);
        Node2_98.add(Node3_369);
        Node2_99.add(Node3_370);
        Node2_99.add(Node3_371);
        Node2_99.add(Node3_372);
        Node2_99.add(Node3_373);
        Node2_99.add(Node3_374);
        Node2_99.add(Node3_375);
        Node2_99.add(Node3_376);
        Node2_99.add(Node3_377);
        Node2_100.add(Node3_378);
        Node2_100.add(Node3_379);
        Node2_100.add(Node3_380);
        Node2_100.add(Node3_381);
        Node2_101.add(Node3_382);
        Node2_101.add(Node3_383);
        Node2_101.add(Node3_384);
        Node2_101.add(Node3_385);
        Node2_102.add(Node3_386);
        Node2_102.add(Node3_387);
        Node2_102.add(Node3_388);
        Node2_103.add(Node3_389);
        Node2_103.add(Node3_390);
        Node2_103.add(Node3_391);
        Node2_104.add(Node3_392);
        Node2_104.add(Node3_393);
        Node2_105.add(Node3_394);
        Node2_105.add(Node3_395);
        Node2_105.add(Node3_396);
        Node2_106.add(Node3_397);
        Node2_106.add(Node3_398);
        Node2_106.add(Node3_399);
        Node2_106.add(Node3_400);
        Node2_106.add(Node3_401);
        Node2_107.add(Node3_402);
        Node2_108.add(Node3_403);
        Node2_108.add(Node3_404);
        Node2_108.add(Node3_405);
        Node2_108.add(Node3_406);
        Node2_109.add(Node3_407);
        Node2_109.add(Node3_408);
        Node2_110.add(Node3_409);
        Node2_110.add(Node3_410);
        Node2_111.add(Node3_411);
        Node2_111.add(Node3_412);
        Node2_111.add(Node3_413);
        Node2_111.add(Node3_414);
        Node2_111.add(Node3_415);
        Node2_112.add(Node3_416);
        Node2_112.add(Node3_417);
        Node2_112.add(Node3_418);
        Node2_112.add(Node3_419);
        Node2_112.add(Node3_420);
        Node2_112.add(Node3_421);
        Node2_112.add(Node3_422);
        Node2_112.add(Node3_423);
        Node2_112.add(Node3_424);
        Node2_112.add(Node3_425);
        Node2_112.add(Node3_426);
        Node2_112.add(Node3_427);
        Node2_113.add(Node3_428);
        Node2_113.add(Node3_429);
        Node2_113.add(Node3_430);
        Node2_113.add(Node3_431);
        Node2_113.add(Node3_432);
        Node2_114.add(Node3_433);
        Node2_114.add(Node3_434);
        Node2_115.add(Node3_435);
        Node2_115.add(Node3_436);
        Node2_116.add(Node3_437);
        Node2_116.add(Node3_438);
        Node2_116.add(Node3_439);
        Node2_116.add(Node3_440);
        Node2_117.add(Node3_441);
        Node2_117.add(Node3_442);
        Node2_118.add(Node3_443);
        Node2_119.add(Node3_444);
        Node2_119.add(Node3_445);
        Node2_119.add(Node3_446);
        Node2_119.add(Node3_447);
        Node2_120.add(Node3_448);
        Node2_120.add(Node3_449);
        Node2_120.add(Node3_450);

        // 使用根节点创建树组件
        JTree tree = new JTree(Node);
        tree.setRootVisible(false);
        // 设置树显示根节点句柄
        tree.setShowsRootHandles(true);
        // 设置树节点可编辑
//        tree.setEditable(true);

        // 设置节点选中监听器
        tree.addTreeSelectionListener(new TreeSelectionListener() {
//            @SuppressWarnings({ "null", "unused" })
			@Override
            public void valueChanged(TreeSelectionEvent e) {
            	String path = e.getPath().toString();
            	char[] ch = path.toCharArray();
            	int n[] = new int[2];
            	int x = 0;
            	for(int i = 7;i < ch.length-1;i++) {
            		if(ch[i] == ',') {
            			n[x] = i;
            			x++;
            		}
            	}
            	if(n[0]==0) {
            		oneMan = java.lang.String.valueOf(ch,7,ch.length-8);
            		twoMan = "-";
            		threeMan = "-";
            	}
            	else if(n[1] == 0) {
            		oneMan = java.lang.String.valueOf(ch,7,n[0]-7);
            		twoMan = java.lang.String.valueOf(ch,n[0]+2,ch.length-n[0]-3);
            		threeMan = "-";
            	}
            	else {
            		oneMan = java.lang.String.valueOf(ch,7,n[0]-7);
            		twoMan = java.lang.String.valueOf(ch,n[0]+2,n[1]-n[0]-2);
            		threeMan = java.lang.String.valueOf(ch,n[1]+2,ch.length-n[1]-3);
            	}
            	numberArea5.setText(oneMan);
        		numberArea7.setText(twoMan);
        		numberArea9.setText(threeMan);
            }
        });
        
        tree.setFont(new Font("正楷",1, 16));
        
        panel.setLayout(new GridLayout(1,1,10,10));
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY,1),"人工分类列表",TitledBorder.CENTER,TitledBorder.TOP,new java.awt.Font("正楷",1,22)));//添加标题
        
        
		// 创建滚动面板，包裹树（因为树节点展开后可能需要很大的空间来显示，所以需要用一个滚动面板来包裹）
        JScrollPane scrollPane = new JScrollPane(tree);
        // 添加滚动面板到内容面板
        panel.add(scrollPane, BorderLayout.CENTER);
		
		//button输出结果点击事件，点击后将sheetA存储的内容写入excel中，完成后再关闭文件
		btnExit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					sheetA.addCell(new Label(0,n,""));
				} catch (WriteException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(1,n,""));
				} catch (WriteException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(2,n,""));
				} catch (WriteException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(3,n,""));
				} catch (WriteException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(4,n,""));
				} catch (WriteException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(9,n,""));
				} catch (WriteException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				// TODO Auto-generated method stub
				try {
					workbookA.write();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					workbookA.close();
				} catch (WriteException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				System.out.print("输出成功！");
			}
		});
		
		//button下一条点击事件，为界面的文本框逐条传递文件中的内容
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String index = check[setbox.getSelectedIndex()];//获取下拉菜单中机器判断情况
				//计算截止到该条语料的判断正确率，通过计算已知的正确的条数除以已判断总数得到	
				if(index == "正确")
					T++;
				accuracy = ((float)Math.round(T*100/n*100))/100;
				System.out.println("目前准确率为：" + accuracy + "%");
				
				//获取人工选择菜单内容
				number_mes5=numberArea5.getText();
				number_mes7=numberArea7.getText();
				number_mes9=numberArea9.getText();
				
				//向excel中写入内容
				try {
					sheetA.addCell(new Label(0,n,number_mes1));
				} catch (WriteException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(1,n,number_mes2));
				} catch (WriteException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(2,n,number_mes4));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(3,n,number_mes6));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(4,n,number_mes8));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(9,n,number_mes3));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(5,n,number_mes5));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(6,n,number_mes7));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(7,n,number_mes9));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(8,n,index));
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(10,n,String.valueOf(accuracy)));
				} catch (WriteException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				//先打印已有内容，再获取下一条内容
				try {
					number_mes1 = readLineVarFile("text/part6.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes2 = readLineVarFile("text/part4.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes3 = readLineVarFile("text/part2.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes4 = readLineVarFile("text/one_classify.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes6 = readLineVarFile("text/two_classify.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes8 = readLineVarFile("text/three_classify.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				numberArea1.setText(number_mes1);
				numberArea2.setText(number_mes2);
				cotArea.setText(number_mes3);
				numberArea4.setText(number_mes4);
				numberArea6.setText(number_mes6);
				numberArea8.setText(number_mes8);
				n++;
				Row = String.valueOf(n);
				numberArea10.setText(Row);
			}
		});
		
		//设计总体布局
		this.setSize(1000, 820);
		this.add(panel);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
	}

	//主函数
	public static void main(String[] args) throws IOException, RowsExceededException, WriteException, BiffException {
		new Classify_tool();
	} 
}    
        