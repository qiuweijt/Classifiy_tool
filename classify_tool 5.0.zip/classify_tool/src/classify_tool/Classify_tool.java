package classify_tool;
import jxl.*;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import java.io.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Enumeration;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class Classify_tool extends JFrame{
	private static final long serialVersionUID = 1L;
	private JButton btnNext;	
	private JButton btnExit;
	private JButton btnSearch;
	private JLabel number;
	private JScrollPane JScrollPane1;
	private String number_mes1;
	private String number_mes2;
	private String number_mes3;
	private String number_mes4;
	private String number_mes5;
	private String number_mes6;
	private String number_mes7;
	private String number_mes8;
	private String number_mes9;
	private String oneMan;
	private String twoMan;
	private String threeMan;
	private String Row;
	private JTextField numberArea1;
	private JTextField numberArea2;
	private JTextArea cotArea;
	private JTextField numberArea4;
	private JTextField numberArea5;
	private JTextField numberArea6;
	private JTextField numberArea7;
	private JTextField numberArea8;
	private JTextField numberArea9;
	private JTextField numberArea10;
	private JTextField searchArea;
	private JLabel jLabel3;
	private String[] check = {"正确","错误"};
//	private String[] title = {"投诉编号", "原始分类", "机器自动分类一级", "机器自动分类二级", "机器自动分类三级",
//	"人工分类一级", "人工分类二级", "人工分类三级","对或错","投诉内容"};
	private String[] title = {"投诉编号", "原始分类", "机器自动分类一级", "机器自动分类二级", "机器自动分类三级", 
			"人工分类一级", "人工分类二级", "人工分类三级","对或错","投诉内容","截止该条准确率(%)"};
	private int[] mark1 = {0,13,18,26,35,41,51,61,73,81,86,91,96,99,107,112,118,120};	//一级列表包含二级列表个数
	private int[] mark2 = {0,4,7,9,15,17,19,21,27,29,38,40,44,46,51,53,56,58,59,63,73,78,87,91,94,96,97,102,106,
			107,112,115,119,124,129,130,133,136,143,146,152,153,157,159,167,171,175,182,184,188,192,193,195,201,
			204,210,213,215,217,219,223,224,227,230,235,238,242,244,248,258,266,270,275,276,280,284,287,290,294,
			296,299,300,305,312,315,317,318,323,338,342,345,346,348,350,353,356,357,367,371,379,383,387,390,393,
			395,398,403,404,408,410,412,417,429,434,436,438,442,444,445,449,452};	//二级列表包含三级列表个数
	@SuppressWarnings("rawtypes")
	private JComboBox setbox;
	private int n;
	private float T = 0;
	private float accuracy = 0;
	private JLabel jLabel4;
	File file = new File("text/社会诉求人工分类和自动分类对比.xls");
	private WritableWorkbook workbookA;
	private WritableSheet sheetA;
	
	//以文件路径读取文件，并获取改文件的指定行的内容
    public String readLineVarFile(String fileName, int lineNumber) throws IOException{ 
			@SuppressWarnings("resource")
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
            String line = reader.readLine();
            String mes = "";
            if (lineNumber <= 0 || lineNumber > getTotalLines(fileName))
			{ 
            	System.out.println("读出错误"); 
            } 
            int num = 1; 
            while (line != null){
            	if (lineNumber == num){ 
            		mes = line;
            		break;
                } 
                num++;
                line = reader.readLine();
            } 
			return mes; 
    } 
     
    //获取文件总行数
    public int getTotalLines(String fileName) throws IOException 
	{ 
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
            LineNumberReader reader = new LineNumberReader(br); 
            String s = reader.readLine();
            int lines = 0; 
            while (s != null)
			{ 
            	lines++; 
            	s = reader.readLine(); 
            } 
            reader.close(); 
            br.close(); 
            return lines;
    } 
	
    //查询树节点
    @SuppressWarnings("rawtypes")
	public DefaultMutableTreeNode searchNode(String nodeStr,DefaultMutableTreeNode Node)
	{
		DefaultMutableTreeNode node = null;
		Enumeration e = Node.breadthFirstEnumeration();
		while (e.hasMoreElements())
		{
			node = (DefaultMutableTreeNode) e.nextElement();
			if (node.getUserObject().toString().indexOf(nodeStr)>=0)
			{
				return node;
			}
		}
		return null;
	}
    
	@SuppressWarnings({ "rawtypes", "unchecked"})
	public Classify_tool() throws IOException, RowsExceededException, WriteException, BiffException {
		
		if(file.exists()) {
   			Workbook workbookB = Workbook.getWorkbook(file);
   			workbookA = Workbook.createWorkbook(file,workbookB);
   			sheetA = workbookA.getSheet(0);
   			Sheet sheetB = workbookB.getSheet(0);
      		int row = sheetB.getRows();
      		n = row-1;
      		Row = String.valueOf(n);
      		String acy = sheetB.getCell(10, n-1).getContents();
      		T = Float.parseFloat(acy)*(n-1)/100;
      	}
      	else {
      		Row = "1";
      		n = 1;
      		file.createNewFile();
      		workbookA = Workbook.createWorkbook(file);
    		sheetA = workbookA.createSheet("工作表1", 0);
      		//设置列名
     		for(int i = 0;i < title.length;i++) {
      			sheetA.addCell(new Label(i,0,title[i]));
      		}
      	}
		number_mes1 = readLineVarFile("text/part6.txt",n);
		number_mes2 = readLineVarFile("text/part4.txt",n);
		number_mes3 = readLineVarFile("text/part2.txt",n);
		number_mes4 = readLineVarFile("text/one_classify.txt",n);
		number_mes6 = readLineVarFile("text/two_classify.txt",n);
		number_mes8 = readLineVarFile("text/three_classify.txt",n);
		oneMan = number_mes4;
		twoMan = number_mes6;
		threeMan = number_mes8;
		
		//JFrame设计布局
		
		this.setTitle("语料标注工具");
		getContentPane().setLayout(null);
		
		//button下一条
		btnNext = new JButton();
		getContentPane().add(btnNext);
		btnNext.setText("下一条");
		btnNext.setBounds(340, 710, 120, 40);
		btnNext.setFont(new Font("正楷", Font.BOLD, 20));
		
		//button输出结果，打印标注内容至excel表格
		btnExit = new JButton();
		getContentPane().add(btnExit);
		btnExit.setText("保存结果");
		btnExit.setBounds(540, 710, 120, 40);
		btnExit.setFont(new Font("正楷", Font.BOLD, 19));

		number = new JLabel();
		getContentPane().add(number);
		number.setText("语料标注工具");
		number.setBounds(410, 20, 180, 25);
		number.setFont(new Font("正楷", Font.BOLD, 26));
		
		number = new JLabel();
		getContentPane().add(number);
		number.setText("投诉编号:");
		number.setBounds(40, 80, 160, 22);
		number.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea1 = new JTextField();
		getContentPane().add(numberArea1);
		numberArea1.setText(number_mes1);
		numberArea1.setBounds(145, 80, 320, 30);
		numberArea1.setFont(new Font("正楷", Font.BOLD ,18));
		
		number = new JLabel();
		getContentPane().add(number);
		number.setText("原始分类:");
		number.setBounds(510, 80, 160, 25);
		number.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea2 = new JTextField();
		getContentPane().add(numberArea2);
		numberArea2.setText(number_mes2);
		numberArea2.setBounds(620, 80, 320, 30);
		numberArea2.setFont(new Font("正楷", Font.BOLD ,18));

		jLabel3 = new JLabel();
		getContentPane().add(jLabel3);
		jLabel3.setText("投诉内容:");
		jLabel3.setBounds(40, 140, 100, 30);
		jLabel3.setFont(new Font("正楷", Font.BOLD, 22));
		
		JScrollPane1 = new JScrollPane();
		getContentPane().add(JScrollPane1);
		JScrollPane1.setBounds(145, 140, 795, 100);
		
		cotArea = new JTextArea();
		cotArea.setBounds(145, 140, 795, 100);
		cotArea.setText(number_mes3);
		cotArea.setLineWrap(true);
		cotArea.setCaretPosition(0);
		cotArea.setFont(new Font("正楷", Font.BOLD, 18));
		JScrollPane1.setViewportView(cotArea);
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器一级:");
		jLabel4.setBounds(40, 270, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea4 = new JTextField();
		getContentPane().add(numberArea4);
		numberArea4.setText(number_mes4);
		numberArea4.setBounds(145, 270, 320, 30);
		numberArea4.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器二级:");
		jLabel4.setBounds(40, 330, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea6 = new JTextField();
		getContentPane().add(numberArea6);
		numberArea6.setText(number_mes6);
		numberArea6.setBounds(145, 330, 320, 30);
		numberArea6.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器三级:");
		jLabel4.setBounds(40, 390, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea8 = new JTextField();
		getContentPane().add(numberArea8);
		numberArea8.setText(number_mes8);
		numberArea8.setBounds(145, 390, 320, 30);
		numberArea8.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("人工一级:");
		jLabel4.setBounds(40, 450, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea5 = new JTextField();
		getContentPane().add(numberArea5);
		numberArea5.setText(oneMan);
		numberArea5.setBounds(145, 450, 320, 30);
		numberArea5.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("人工二级:");
		jLabel4.setBounds(40, 510, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea7 = new JTextField();
		getContentPane().add(numberArea7);
		numberArea7.setText(twoMan);
		numberArea7.setBounds(145, 510, 320, 30);
		numberArea7.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("人工三级:");
		jLabel4.setBounds(40, 570, 100, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		numberArea9 = new JTextField();
		getContentPane().add(numberArea9);
		numberArea9.setText(threeMan);
		numberArea9.setBounds(145, 570, 320, 30);
		numberArea9.setFont(new Font("正楷", Font.BOLD ,18));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("机器判断情况:");
		jLabel4.setBounds(40, 630, 160, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 22));
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("第");
		jLabel4.setBounds(40, 690, 25, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 20));
		
		numberArea10 = new JTextField();
		getContentPane().add(numberArea10);
		numberArea10.setText(Row);
		numberArea10.setBounds(65, 693, 50, 27);
		numberArea10.setFont(new Font("正楷", Font.BOLD ,18));
		numberArea10.setBorder(null);
		numberArea10.setSelectionColor(getBackground());;
		
		jLabel4 = new JLabel();
		getContentPane().add(jLabel4);
		jLabel4.setText("条");
		jLabel4.setBounds(120, 690, 30, 30);
		jLabel4.setFont(new Font("正楷", Font.BOLD, 20));
		
		//机器判断情况的下拉菜单
		ComboBoxModel setboxModel = new DefaultComboBoxModel(check);
		setbox = new JComboBox();
		getContentPane().add(setbox);
		setbox.setModel(setboxModel);
		setbox.setBounds(210, 630, 90, 33);
		setbox.setFont(new Font("正楷", Font.BOLD, 20));
		
		//添加树形目录面板
		JPanel treePanel = new JPanel(new BorderLayout());
		treePanel.setBounds(540, 260, 400, 380);
		
		//添加搜索面板
		JPanel schPanel = new JPanel();
		schPanel.setBounds(542, 640, 398, 36);
		schPanel.setBorder(BorderFactory.createEtchedBorder());
		schPanel.setLayout(null);
		
		searchArea = new JTextField();
		schPanel.add(searchArea);
		searchArea.setBounds(8, 1, 310, 32);
		searchArea.setFont(new Font("正楷", Font.BOLD, 16));
		
		btnSearch = new JButton();
		schPanel.add(btnSearch);
		btnSearch.setText("搜索");
		btnSearch.setBounds(320, 1, 70, 33);
		btnSearch.setFont(new Font("正楷", Font.BOLD, 16));
			
        //根节点
        DefaultMutableTreeNode Node = new DefaultMutableTreeNode("人工分类");
        
        //根据文件行数创建对应长度的节点数组
        DefaultMutableTreeNode [] Node1 = new DefaultMutableTreeNode[getTotalLines("text/one_column.txt")];
        DefaultMutableTreeNode [] Node2 = new DefaultMutableTreeNode[getTotalLines("text/two_column.txt")];
        DefaultMutableTreeNode [] Node3 = new DefaultMutableTreeNode[getTotalLines("text/three_column.txt")];
        
        //从文件中循环新建节点
        for(int i = 0;i<getTotalLines("text/one_column.txt");i++) {
        	Node1[i] = new DefaultMutableTreeNode(readLineVarFile("text/one_column.txt",i+1));
        	Node.add(Node1[i]);
        }
        for(int i = 0;i<getTotalLines("text/two_column.txt");i++) {
        	Node2[i]  = new DefaultMutableTreeNode(readLineVarFile("text/two_column.txt",i+1));
        }
        for(int i = 0;i<getTotalLines("text/three_column.txt");i++) {
        	Node3[i]  = new DefaultMutableTreeNode(readLineVarFile("text/three_column.txt",i+1));
        }

        //循环生成树形列表
        for(int i = 0;i<getTotalLines("text/one_column.txt");i++) {
        	for(int j = mark1[i];j<mark1[i+1];j++) {
        		Node1[i].add(Node2[j]);
        		for(int k = mark2[j];k<mark2[j+1];k++) {
        			Node2[j].add(Node3[k]);
        		}
        	}
        }

        // 使用根节点创建树组件
        JTree tree = new JTree(Node);
        tree.setRootVisible(false);
        // 设置树显示根节点句柄
        tree.setShowsRootHandles(true);
        // 设置树节点可编辑
//        tree.setEditable(true);

        tree.setFont(new Font("正楷",1, 16));
//      treePanel.setLayout(new GridLayout(1,1,10,10));
        treePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY,1),"人工分类列表",TitledBorder.CENTER,TitledBorder.TOP,new java.awt.Font("正楷",1,22)));//添加标题
      
		// 创建滚动面板，包裹树（因为树节点展开后可能需要很大的空间来显示，所以需要用一个滚动面板来包裹）
        JScrollPane scrollPane = new JScrollPane(tree);
        // 添加滚动面板到内容面板
        treePanel.add(scrollPane);
        
        // 设置节点选中监听器
        tree.addTreeSelectionListener(new TreeSelectionListener() {
			@Override
            public void valueChanged(TreeSelectionEvent e) {
            	String path = e.getPath().toString();
            	char[] ch = path.toCharArray();
            	int n[] = new int[2];
            	int x = 0;
            	for(int i = 7;i < ch.length-1;i++) {
            		if(ch[i] == ',') {
            			n[x] = i;
            			x++;
            		}
            	}
            	if(n[0]==0) {
            		oneMan = java.lang.String.valueOf(ch,7,ch.length-8);
            		twoMan = "-";
            		threeMan = "-";
            	}
            	else if(n[1] == 0) {
            		oneMan = java.lang.String.valueOf(ch,7,n[0]-7);
            		twoMan = java.lang.String.valueOf(ch,n[0]+2,ch.length-n[0]-3);
            		threeMan = "-";
            	}
            	else {
            		oneMan = java.lang.String.valueOf(ch,7,n[0]-7);
            		twoMan = java.lang.String.valueOf(ch,n[0]+2,n[1]-n[0]-2);
            		threeMan = java.lang.String.valueOf(ch,n[1]+2,ch.length-n[1]-3);
            	}
            	numberArea5.setText(oneMan);
        		numberArea7.setText(twoMan);
        		numberArea9.setText(threeMan);
            }
        });
        
        //btnSearch点击事件，搜索点击事件
        btnSearch.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		DefaultMutableTreeNode node = searchNode(searchArea.getText(),Node);
        		DefaultTreeModel tree_model = new DefaultTreeModel(Node);
        		if(node != null) {
        			TreeNode[] nodes = tree_model.getPathToRoot(node);
        			TreePath path = new TreePath(nodes);
        			tree.scrollPathToVisible(path);
        			tree.setSelectionPath(path);
        		}
        		else {
        			System.out.print("未查询到分类" + searchArea.getText());
        		}
        	}
        });
        
		//button保存结果点击事件，点击后将sheetA存储的内容写入excel中，完成后再关闭文件
		btnExit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					sheetA.addCell(new Label(0,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(1,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(2,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(3,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(4,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(9,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					workbookA.write();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				System.out.print("保存成功！\n");
			}
		});
		
		//button下一条点击事件，为界面的文本框逐条传递文件中的内容
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String index = check[setbox.getSelectedIndex()];//获取下拉菜单中机器判断情况
				//计算截止到该条语料的判断正确率，通过计算已知的正确的条数除以已判断总数得到	
				if(index == "正确")
					T++;
				accuracy = ((float)Math.round(T*100/n*100))/100;
				System.out.println("目前准确率为：" + accuracy + "%");
				
				//获取人工选择菜单内容
				number_mes5=numberArea5.getText();
				number_mes7=numberArea7.getText();
				number_mes9=numberArea9.getText();
				
				//向excel中写入内容
				try {
					sheetA.addCell(new Label(0,n,number_mes1));
				} catch (WriteException e2) {
					e2.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(1,n,number_mes2));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(2,n,number_mes4));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(3,n,number_mes6));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(4,n,number_mes8));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(9,n,number_mes3));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(5,n,number_mes5));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(6,n,number_mes7));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(7,n,number_mes9));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(8,n,index));
				} catch (WriteException e1) {
					e1.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(10,n,String.valueOf(accuracy)));
				} catch (WriteException e2) {
					e2.printStackTrace();
				}
				
				//先打印已有内容，再获取下一条内容
				try {
					number_mes1 = readLineVarFile("text/part6.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes2 = readLineVarFile("text/part4.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes3 = readLineVarFile("text/part2.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes4 = readLineVarFile("text/one_classify.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes6 = readLineVarFile("text/two_classify.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					number_mes8 = readLineVarFile("text/three_classify.txt",n+1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				numberArea1.setText(number_mes1);
				numberArea2.setText(number_mes2);
				cotArea.setText(number_mes3);
				numberArea4.setText(number_mes4);
				numberArea5.setText(number_mes4);
				numberArea6.setText(number_mes6);
				numberArea7.setText(number_mes6);
				numberArea8.setText(number_mes8);
				numberArea9.setText(number_mes8);
				n++;
				Row = String.valueOf(n);
				numberArea10.setText(Row);
			}
		});
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				try {
					sheetA.addCell(new Label(0,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(1,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(2,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(3,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(4,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					sheetA.addCell(new Label(9,n,""));
				} catch (WriteException e3) {
					e3.printStackTrace();
				}
				try {
					workbookA.write();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
				try {
					workbookA.close();
				} catch (WriteException | IOException e1) {
					e1.printStackTrace();
				}
				System.exit(0);
			}
		});
		
		//设计总体布局
		this.setSize(1000, 820);
		this.add(treePanel);
		this.add(schPanel);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setResizable(true);
	}

	//主函数
	public static void main(String[] args) throws IOException, RowsExceededException, WriteException, BiffException {
		new Classify_tool();
	} 
}    
        